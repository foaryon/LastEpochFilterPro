import { 
  type Build, 
  type InsertBuild,
  type GeneratedFilter,
  type InsertGeneratedFilter,
  type AIAnalysis,
  type InsertAIAnalysis,
  type User, 
  type InsertUser,
  type Character,
  type InsertCharacter,
  type CharacterGear,
  type InsertCharacterGear,
  type CharacterIdol,
  type InsertCharacterIdol,
  type PersonalizedFilter,
  type InsertPersonalizedFilter
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Build management
  getBuild(id: string): Promise<Build | undefined>;
  getAllBuilds(): Promise<Build[]>;
  createBuild(build: InsertBuild): Promise<Build>;

  // Generated filter management
  getGeneratedFilterById(id: string): Promise<GeneratedFilter | undefined>;
  getGeneratedFiltersByBuildId(buildId: string): Promise<GeneratedFilter[]>;
  createGeneratedFilter(filter: InsertGeneratedFilter): Promise<GeneratedFilter>;

  // AI analysis management
  getAIAnalysisForBuild(buildId: string): Promise<AIAnalysis[]>;
  createAIAnalysis(analysis: InsertAIAnalysis): Promise<AIAnalysis>;

  // Character management
  getCharacter(id: string): Promise<Character | undefined>;
  getAllCharacters(): Promise<Character[]>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: string, updates: Partial<Character>): Promise<Character>;

  // Character gear management
  getCharacterGear(characterId: string): Promise<CharacterGear[]>;
  createCharacterGear(gear: InsertCharacterGear): Promise<CharacterGear>;
  updateCharacterGear(id: string, updates: Partial<CharacterGear>): Promise<CharacterGear>;
  deleteCharacterGear(characterId: string): Promise<void>;

  // Character idol management
  getCharacterIdols(characterId: string): Promise<CharacterIdol[]>;
  createCharacterIdol(idol: InsertCharacterIdol): Promise<CharacterIdol>;
  updateCharacterIdol(id: string, updates: Partial<CharacterIdol>): Promise<CharacterIdol>;
  deleteCharacterIdols(characterId: string): Promise<void>;

  // Personalized filter management
  getPersonalizedFilter(characterId: string, targetCorruption: number): Promise<PersonalizedFilter | undefined>;
  createPersonalizedFilter(filter: InsertPersonalizedFilter): Promise<PersonalizedFilter>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private builds: Map<string, Build>;
  private generatedFilters: Map<string, GeneratedFilter>;
  private aiAnalysis: Map<string, AIAnalysis>;
  private characters: Map<string, Character>;
  private characterGear: Map<string, CharacterGear>;
  private characterIdols: Map<string, CharacterIdol>;
  private personalizedFilters: Map<string, PersonalizedFilter>;

  constructor() {
    this.users = new Map();
    this.builds = new Map();
    this.generatedFilters = new Map();
    this.aiAnalysis = new Map();
    this.characters = new Map();
    this.characterGear = new Map();
    this.characterIdols = new Map();
    this.personalizedFilters = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      preferences: {},
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Build methods
  async getBuild(id: string): Promise<Build | undefined> {
    return this.builds.get(id);
  }

  async getAllBuilds(): Promise<Build[]> {
    return Array.from(this.builds.values());
  }

  async createBuild(insertBuild: InsertBuild): Promise<Build> {
    const id = insertBuild.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    const build: Build = { 
      ...insertBuild, 
      id,
      isNew: insertBuild.isNew ?? false,
      createdAt: new Date()
    };
    this.builds.set(id, build);
    return build;
  }

  // Generated filter methods
  async getGeneratedFilterById(id: string): Promise<GeneratedFilter | undefined> {
    return this.generatedFilters.get(id);
  }

  async getGeneratedFiltersByBuildId(buildId: string): Promise<GeneratedFilter[]> {
    return Array.from(this.generatedFilters.values()).filter(
      filter => filter.buildId === buildId
    );
  }

  async createGeneratedFilter(insertFilter: InsertGeneratedFilter): Promise<GeneratedFilter> {
    const id = randomUUID();
    const filter: GeneratedFilter = { 
      ...insertFilter, 
      id,
      createdAt: new Date()
    } as GeneratedFilter;
    this.generatedFilters.set(id, filter);
    return filter;
  }

  // AI analysis methods
  async getAIAnalysisForBuild(buildId: string): Promise<AIAnalysis[]> {
    return Array.from(this.aiAnalysis.values()).filter(
      analysis => analysis.buildId === buildId
    );
  }

  async createAIAnalysis(insertAnalysis: InsertAIAnalysis): Promise<AIAnalysis> {
    const id = randomUUID();
    const analysis: AIAnalysis = { 
      ...insertAnalysis, 
      id,
      metadata: insertAnalysis.metadata ?? null,
      createdAt: new Date()
    };
    this.aiAnalysis.set(id, analysis);
    return analysis;
  }

  // Character methods
  async getCharacter(id: string): Promise<Character | undefined> {
    return this.characters.get(id);
  }

  async getAllCharacters(): Promise<Character[]> {
    return Array.from(this.characters.values());
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const id = randomUUID();
    const character: Character = {
      ...insertCharacter,
      id,
      createdAt: new Date(),
      lastAnalyzed: new Date()
    };
    this.characters.set(id, character);
    return character;
  }

  async updateCharacter(id: string, updates: Partial<Character>): Promise<Character> {
    const character = this.characters.get(id);
    if (!character) {
      throw new Error('Character not found');
    }
    const updatedCharacter = { ...character, ...updates };
    this.characters.set(id, updatedCharacter);
    return updatedCharacter;
  }

  // Character gear methods
  async getCharacterGear(characterId: string): Promise<CharacterGear[]> {
    return Array.from(this.characterGear.values()).filter(
      gear => gear.characterId === characterId
    );
  }

  async createCharacterGear(insertGear: InsertCharacterGear): Promise<CharacterGear> {
    const id = randomUUID();
    const gear: CharacterGear = {
      ...insertGear,
      id,
      createdAt: new Date()
    };
    this.characterGear.set(id, gear);
    return gear;
  }

  async updateCharacterGear(id: string, updates: Partial<CharacterGear>): Promise<CharacterGear> {
    const gear = this.characterGear.get(id);
    if (!gear) {
      throw new Error('Character gear not found');
    }
    const updatedGear = { ...gear, ...updates };
    this.characterGear.set(id, updatedGear);
    return updatedGear;
  }

  async deleteCharacterGear(characterId: string): Promise<void> {
    const gearToDelete = Array.from(this.characterGear.entries())
      .filter(([_, gear]) => gear.characterId === characterId);
    
    gearToDelete.forEach(([id, _]) => {
      this.characterGear.delete(id);
    });
  }

  // Character idol methods
  async getCharacterIdols(characterId: string): Promise<CharacterIdol[]> {
    return Array.from(this.characterIdols.values()).filter(
      idol => idol.characterId === characterId
    );
  }

  async createCharacterIdol(insertIdol: InsertCharacterIdol): Promise<CharacterIdol> {
    const id = randomUUID();
    const idol: CharacterIdol = {
      ...insertIdol,
      id,
      createdAt: new Date()
    };
    this.characterIdols.set(id, idol);
    return idol;
  }

  async updateCharacterIdol(id: string, updates: Partial<CharacterIdol>): Promise<CharacterIdol> {
    const idol = this.characterIdols.get(id);
    if (!idol) {
      throw new Error('Character idol not found');
    }
    const updatedIdol = { ...idol, ...updates };
    this.characterIdols.set(id, updatedIdol);
    return updatedIdol;
  }

  async deleteCharacterIdols(characterId: string): Promise<void> {
    const idolsToDelete = Array.from(this.characterIdols.entries())
      .filter(([_, idol]) => idol.characterId === characterId);
    
    idolsToDelete.forEach(([id, _]) => {
      this.characterIdols.delete(id);
    });
  }

  // Personalized filter methods
  async getPersonalizedFilter(characterId: string, targetCorruption: number): Promise<PersonalizedFilter | undefined> {
    return Array.from(this.personalizedFilters.values()).find(
      filter => filter.characterId === characterId && filter.targetCorruption === targetCorruption
    );
  }

  async createPersonalizedFilter(insertFilter: InsertPersonalizedFilter): Promise<PersonalizedFilter> {
    const id = randomUUID();
    const filter: PersonalizedFilter = {
      ...insertFilter,
      id,
      createdAt: new Date()
    };
    this.personalizedFilters.set(id, filter);
    return filter;
  }
}

export const storage = new MemStorage();
