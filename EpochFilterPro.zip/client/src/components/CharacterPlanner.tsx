import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient } from "../lib/queryClient";
import { useToast } from "../hooks/use-toast";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";

interface CharacterPlannerProps {
  onFilterGenerated?: (filterData: any) => void;
}

function CharacterPlanner({ onFilterGenerated }: CharacterPlannerProps) {
  const [selectedCharacter, setSelectedCharacter] = useState<any>(null);
  const [importData, setImportData] = useState({
    name: "",
    className: "Sentinel",
    mastery: "Void Knight",
    level: 95,
    importSource: "manual_input" as const
  });
  const { toast } = useToast();

  // Fetch characters
  const { data: charactersData, isLoading: charactersLoading } = useQuery({
    queryKey: ["/api/characters"],
    staleTime: 30000,
  });

  // Import character mutation
  const importCharacterMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/characters/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to import character");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setSelectedCharacter(data.character);
      queryClient.invalidateQueries({ queryKey: ["/api/characters"] });
      toast({
        title: "Character Imported!",
        description: `${data.character.name} has been analyzed and is ready for personalized filters.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Import Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Analyze character mutation
  const analyzeCharacterMutation = useMutation({
    mutationFn: async (characterId: string) => {
      const response = await fetch(`/api/characters/${characterId}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to analyze character");
      }
      
      return response.json();
    },
  });

  // Generate personalized filter mutation
  const generatePersonalizedFilterMutation = useMutation({
    mutationFn: async (data: { characterId: string; targetCorruption: number }) => {
      const response = await fetch("/api/characters/personalized-filter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to generate personalized filter");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      if (onFilterGenerated) {
        onFilterGenerated(data);
      }
      toast({
        title: "Personalized Filter Created!",
        description: `Filter optimized for ${data.characterName}'s weakest gear pieces.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Filter Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleImportCharacter = () => {
    if (!importData.name.trim()) {
      toast({
        title: "Missing Character Name",
        description: "Please enter a character name to import.",
        variant: "destructive",
      });
      return;
    }
    importCharacterMutation.mutate(importData);
  };

  const handleGeneratePersonalizedFilter = (characterId: string) => {
    generatePersonalizedFilterMutation.mutate({
      characterId,
      targetCorruption: 300 // Default corruption for demo
    });
  };

  const characters = (charactersData as any)?.characters || [];
  const isAnalyzing = analyzeCharacterMutation.isPending;
  const isGenerating = generatePersonalizedFilterMutation.isPending;
  const analysisData = analyzeCharacterMutation.data;

  return (
    <div className="space-y-6" data-testid="character-planner">
      {/* Character Import Section */}
      <Card className="neon-glow">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <i className="fas fa-user-plus text-primary" data-testid="icon-user-plus"></i>
            <span>Character Import</span>
          </CardTitle>
          <CardDescription>
            Import your character data to generate personalized loot filters targeting your weakest gear
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Character Name</label>
              <input 
                type="text"
                value={importData.name}
                onChange={(e) => setImportData({...importData, name: e.target.value})}
                className="w-full bg-input border border-border rounded px-3 py-2"
                placeholder="Enter character name"
                data-testid="input-character-name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Level</label>
              <input 
                type="number"
                min="1"
                max="100"
                value={importData.level}
                onChange={(e) => setImportData({...importData, level: parseInt(e.target.value)})}
                className="w-full bg-input border border-border rounded px-3 py-2"
                data-testid="input-character-level"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Class</label>
              <select 
                value={importData.className}
                onChange={(e) => setImportData({...importData, className: e.target.value})}
                className="w-full bg-input border border-border rounded px-3 py-2"
                data-testid="select-character-class"
              >
                <option value="Sentinel">Sentinel</option>
                <option value="Rogue">Rogue</option>
                <option value="Acolyte">Acolyte</option>
                <option value="Primalist">Primalist</option>
                <option value="Mage">Mage</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Mastery</label>
              <select 
                value={importData.mastery}
                onChange={(e) => setImportData({...importData, mastery: e.target.value})}
                className="w-full bg-input border border-border rounded px-3 py-2"
                data-testid="select-character-mastery"
              >
                {importData.className === "Sentinel" && (
                  <>
                    <option value="Paladin">Paladin</option>
                    <option value="Void Knight">Void Knight</option>
                    <option value="Forge Guard">Forge Guard</option>
                  </>
                )}
                {importData.className === "Rogue" && (
                  <>
                    <option value="Marksman">Marksman</option>
                    <option value="Blade Dancer">Blade Dancer</option>
                    <option value="Falconer">Falconer</option>
                  </>
                )}
                {importData.className === "Acolyte" && (
                  <>
                    <option value="Necromancer">Necromancer</option>
                    <option value="Lich">Lich</option>
                    <option value="Warlock">Warlock</option>
                  </>
                )}
                {importData.className === "Primalist" && (
                  <>
                    <option value="Beastmaster">Beastmaster</option>
                    <option value="Shaman">Shaman</option>
                    <option value="Druid">Druid</option>
                  </>
                )}
                {importData.className === "Mage" && (
                  <>
                    <option value="Sorcerer">Sorcerer</option>
                    <option value="Spellblade">Spellblade</option>
                    <option value="Runemaster">Runemaster</option>
                  </>
                )}
              </select>
            </div>
          </div>
          <Button 
            onClick={handleImportCharacter}
            disabled={importCharacterMutation.isPending}
            className="w-full bg-primary hover:bg-primary/90"
            data-testid="button-import-character"
          >
            {importCharacterMutation.isPending ? (
              <>
                <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2"></div>
                Importing Character...
              </>
            ) : (
              <>
                <i className="fas fa-download mr-2"></i>
                Import Character
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Character List */}
      <Card>
        <CardHeader>
          <CardTitle>Imported Characters</CardTitle>
        </CardHeader>
        <CardContent>
          {charactersLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              <span className="ml-2">Loading characters...</span>
            </div>
          ) : characters.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <i className="fas fa-users text-4xl mb-4"></i>
              <p>No characters imported yet. Import your first character above!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {characters.map((character: any) => (
                <div 
                  key={character.id} 
                  className={`bg-accent/10 border border-accent/30 rounded-lg p-4 cursor-pointer transition-all ${
                    selectedCharacter?.id === character.id ? 'border-primary neon-glow' : ''
                  }`}
                  onClick={() => setSelectedCharacter(character)}
                  data-testid={`card-character-${character.id}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-lg" data-testid={`text-character-name-${character.id}`}>
                      {character.name}
                    </h3>
                    <Badge variant="secondary">Level {character.level}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    {character.className} - {character.mastery}
                  </p>
                  <div className="flex space-x-2">
                    <Button 
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation();
                        analyzeCharacterMutation.mutate(character.id);
                      }}
                      disabled={isAnalyzing}
                      data-testid={`button-analyze-${character.id}`}
                    >
                      <i className="fas fa-search mr-1"></i>
                      Analyze
                    </Button>
                    <Button 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleGeneratePersonalizedFilter(character.id);
                      }}
                      disabled={isGenerating}
                      data-testid={`button-generate-filter-${character.id}`}
                    >
                      <i className="fas fa-filter mr-1"></i>
                      Generate Filter
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Gap Analysis Results */}
      {selectedCharacter && analysisData && (
        <Card className="bg-chart-2/10 border-chart-2/20">
          <CardHeader>
            <CardTitle className="text-chart-2">
              <i className="fas fa-chart-line mr-2"></i>
              Gap Analysis: {selectedCharacter.name}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-chart-2" data-testid="text-overall-score">
                  {analysisData.gapAnalysis.overallScore}%
                </div>
                <div className="text-sm text-muted-foreground">Overall Score</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-chart-3" data-testid="text-improvement-potential">
                  {analysisData.gapAnalysis.improvementPotential}%
                </div>
                <div className="text-sm text-muted-foreground">Improvement Potential</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary" data-testid="text-weakest-slots-count">
                  {analysisData.gapAnalysis.weakestSlots.length}
                </div>
                <div className="text-sm text-muted-foreground">Priority Slots</div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold">Weakest Gear Slots (Priority Order):</h4>
              <div className="flex flex-wrap gap-2">
                {analysisData.gapAnalysis.weakestSlots.map((slot: string, index: number) => (
                  <Badge 
                    key={slot} 
                    variant={index === 0 ? "destructive" : "secondary"}
                    data-testid={`badge-weak-slot-${index}`}
                  >
                    #{index + 1} {slot.replace('_', ' ')}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold">AI Recommendations:</h4>
              <ul className="space-y-1 text-sm">
                {analysisData.gapAnalysis.recommendations.map((rec: string, index: number) => (
                  <li key={index} className="flex items-start space-x-2" data-testid={`recommendation-${index}`}>
                    <span className="text-chart-2 mt-1">•</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default CharacterPlanner;