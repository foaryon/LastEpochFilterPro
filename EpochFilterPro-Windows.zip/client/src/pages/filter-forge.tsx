import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import BuildCard from "../components/BuildCard";
import CorruptionCalculator from "../components/CorruptionCalculator";
import AIStatusPanel from "../components/AIStatusPanel";
import FilterExport from "../components/FilterExport";
import Navigation from "../components/Navigation";
import type { Build } from "@shared/schema";

export default function FilterForge() {
  const [selectedBuild, setSelectedBuild] = useState<Build | null>(null);
  const [playerLevel, setPlayerLevel] = useState(95);
  const [targetCorruption, setTargetCorruption] = useState(300);
  const [faction, setFaction] = useState<"merchants_guild" | "circle_of_fortune">("merchants_guild");
  const [generatedFilter, setGeneratedFilter] = useState<any>(null);
  const { toast } = useToast();

  // Fetch all available builds
  const { data: buildsData, isLoading: buildsLoading } = useQuery({
    queryKey: ["/api/builds"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Generate filter mutation
  const generateFilterMutation = useMutation({
    mutationFn: async (data: {
      buildId: string;
      playerLevel: number;
      targetCorruption: number;
      faction: string;
    }) => {
      const response = await fetch("/api/generate-filter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to generate filter");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedFilter(data);
      toast({
        title: "Filter Generated Successfully!",
        description: `${data.aiEnhanced ? 'AI-Enhanced' : 'Progressive'} filter created for ${data.buildName}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Filter Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Corruption calculation mutation
  const corruptionCalcMutation = useMutation({
    mutationFn: async (data: { buildId: string; targetCorruption: number }) => {
      const response = await fetch("/api/calculate-corruption", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to calculate corruption requirements");
      }
      
      return response.json();
    },
  });

  // Auto-generate filter when build/parameters change
  useEffect(() => {
    if (selectedBuild && playerLevel && targetCorruption) {
      generateFilterMutation.mutate({
        buildId: selectedBuild.id,
        playerLevel,
        targetCorruption,
        faction,
      });

      // Also calculate corruption requirements
      corruptionCalcMutation.mutate({
        buildId: selectedBuild.id,
        targetCorruption,
      });
    }
  }, [selectedBuild?.id, playerLevel, targetCorruption, faction]);

  const builds = (buildsData as any)?.builds || [];
  const corruptionData = corruptionCalcMutation.data;

  return (
    <div className="min-h-screen last-epoch-bg">
      <Navigation />
      <div className="min-h-screen text-foreground">
      {/* Header */}
      <header className="border-b border-border gothic-border backdrop-blur-sm sticky top-0 z-50 stone-texture" data-testid="header-main">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center neon-glow">
                <i className="fas fa-brain text-primary-foreground text-xl" data-testid="icon-ai-brain"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold metallic-text" data-testid="text-app-title">LE AI Filter Forge</h1>
                <p className="text-sm text-muted-foreground" data-testid="text-app-subtitle">Season 3 S-Tier Build Optimizer</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 parchment px-3 py-2 rounded-lg" data-testid="status-ai-learning">
                <div className="w-2 h-2 rarity-set rounded-full ai-pulse"></div>
                <span className="text-sm font-medium">AI Learning Active</span>
              </div>
              <div className="text-sm text-muted-foreground" data-testid="text-filters-generated">
                Filters Generated: <span className="text-primary font-bold">2,847</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-8">
            {/* AI Status Panel */}
            <AIStatusPanel 
              isLoading={generateFilterMutation.isPending}
              filterData={generatedFilter}
            />

            {/* Build Selection Grid */}
            <div className="gothic-border rounded-xl p-6 filter-section">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold metallic-text" data-testid="text-builds-title">Season 3 S-Tier Builds</h2>
                <div className="flex items-center space-x-2 px-3 py-1 rounded-full text-sm mystical-glow rarity-exalted" data-testid="badge-meta-updated">
                  <i className="fas fa-star"></i>
                  <span>Meta Updated</span>
                </div>
              </div>
              
              {buildsLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Array.from({ length: 6 }, (_, i) => (
                    <div key={i} className="bg-accent/10 border border-accent/30 rounded-lg p-4 animate-pulse" data-testid={`skeleton-build-${i}`}>
                      <div className="h-10 w-10 bg-accent/30 rounded-lg mb-3"></div>
                      <div className="h-4 bg-accent/30 rounded mb-2"></div>
                      <div className="h-3 bg-accent/20 rounded mb-2"></div>
                      <div className="flex justify-between">
                        <div className="h-3 w-12 bg-accent/20 rounded"></div>
                        <div className="h-3 w-12 bg-accent/20 rounded"></div>
                        <div className="h-3 w-12 bg-accent/20 rounded"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 build-grid">
                  {builds.map((build: Build) => (
                    <BuildCard
                      key={build.id}
                      build={build}
                      isSelected={selectedBuild?.id === build.id}
                      onSelect={() => setSelectedBuild(build)}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-4">
            {/* Selected Build Info */}
            <div className="gothic-border rounded-xl p-6 mb-6 filter-section" data-testid="panel-selected-build">
              <h3 className="text-lg font-bold mb-4 gold-text">Selected Build</h3>
              <div id="selected-build-info">
                {selectedBuild ? (
                  <div className="text-left">
                    <h4 className="font-semibold text-lg mb-2" data-testid="text-selected-build-name">{selectedBuild.name}</h4>
                    <p className="text-sm text-muted-foreground mb-4" data-testid="text-selected-build-desc">{selectedBuild.description}</p>
                    {generateFilterMutation.isPending ? (
                      <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
                        <div className="flex items-center space-x-2 mb-2">
                          <div className="w-2 h-2 bg-chart-2 rounded-full animate-pulse"></div>
                          <span className="text-sm font-medium">AI Analyzing Build...</span>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          • Calculating optimal affix priorities<br/>
                          • Determining corruption thresholds<br/>
                          • Generating filter rules
                        </div>
                      </div>
                    ) : generatedFilter ? (
                      <div className="bg-chart-2/10 border border-chart-2/20 rounded-lg p-3">
                        <div className="flex items-center space-x-2 mb-2">
                          <i className="fas fa-check-circle text-chart-2"></i>
                          <span className="text-sm font-medium">Filter Generated!</span>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          • {generatedFilter.rules.length} filter rules created<br/>
                          • Strictness: {generatedFilter.strictnessLevel}<br/>
                          • {generatedFilter.aiEnhanced ? 'AI Enhanced' : 'Progressive'} optimization
                        </div>
                      </div>
                    ) : null}
                  </div>
                ) : (
                  <div className="text-center py-8" data-testid="empty-state-build-selection">
                    <i className="fas fa-mouse-pointer text-4xl text-muted-foreground mb-4"></i>
                    <p className="text-muted-foreground">Select a build to generate AI-optimized filters</p>
                  </div>
                )}
              </div>
            </div>

            {/* Corruption Calculator */}
            <CorruptionCalculator
              playerLevel={playerLevel}
              targetCorruption={targetCorruption}
              onLevelChange={setPlayerLevel}
              onCorruptionChange={setTargetCorruption}
              corruptionData={corruptionData}
              isCalculating={corruptionCalcMutation.isPending}
            />

            {/* AI Settings */}
            <div className="bg-card border border-border rounded-xl p-6 mb-6" data-testid="panel-ai-settings">
              <h3 className="text-lg font-bold mb-4">AI Optimization</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Autonomous Mode</span>
                  <div className="w-12 h-6 bg-primary rounded-full relative">
                    <div className="w-5 h-5 bg-primary-foreground rounded-full absolute top-0.5 right-0.5"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Learning Enabled</span>
                  <div className="w-12 h-6 bg-primary rounded-full relative">
                    <div className="w-5 h-5 bg-primary-foreground rounded-full absolute top-0.5 right-0.5"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Real-time Updates</span>
                  <div className="w-12 h-6 bg-primary rounded-full relative">
                    <div className="w-5 h-5 bg-primary-foreground rounded-full absolute top-0.5 right-0.5"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Faction</span>
                  <select 
                    value={faction} 
                    onChange={(e) => setFaction(e.target.value as any)}
                    className="bg-input border border-border rounded px-2 py-1 text-sm"
                    data-testid="select-faction"
                  >
                    <option value="merchants_guild">Merchant's Guild</option>
                    <option value="circle_of_fortune">Circle of Fortune</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Filter Export */}
            <FilterExport 
              generatedFilter={generatedFilter}
              isLoading={generateFilterMutation.isPending}
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border bg-card/30 mt-16" data-testid="footer-main">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="font-semibold mb-4">AI Capabilities</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Autonomous build discovery</li>
                <li>• Real-time filter optimization</li>
                <li>• Corruption scaling analysis</li>
                <li>• Community data integration</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Data Sources</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Maxroll.gg tier lists</li>
                <li>• LastEpochTools database</li>
                <li>• Community guides analysis</li>
                <li>• Live game data mining</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Filter Features</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Progressive strictness</li>
                <li>• Idol optimization</li>
                <li>• Legendary potential targeting</li>
                <li>• Faction-specific rules</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-6 text-center text-sm text-muted-foreground">
            <p>LE AI Filter Forge - Powered by advanced machine learning and community data</p>
            <p className="mt-1">Season 3 "Beneath Ancient Skies" - Updated for Patch 1.3</p>
          </div>
        </div>
      </footer>
      </div>
    </div>
  );
}
