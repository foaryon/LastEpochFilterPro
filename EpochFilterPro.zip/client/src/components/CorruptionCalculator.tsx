import { useEffect } from "react";

interface CorruptionCalculatorProps {
  playerLevel: number;
  targetCorruption: number;
  onLevelChange: (level: number) => void;
  onCorruptionChange: (corruption: number) => void;
  corruptionData?: any;
  isCalculating: boolean;
}

export default function CorruptionCalculator({
  playerLevel,
  targetCorruption,
  onLevelChange,
  onCorruptionChange,
  corruptionData,
  isCalculating
}: CorruptionCalculatorProps) {
  
  const formatDPS = (dps: number): string => {
    if (dps >= 1000000) {
      return `${(dps / 1000000).toFixed(1)}M`;
    } else if (dps >= 1000) {
      return `${(dps / 1000).toFixed(0)}K`;
    }
    return dps.toString();
  };

  const getCorruptionColor = (corruption: number): string => {
    if (corruption >= 800) return "from-destructive to-destructive/60";
    if (corruption >= 500) return "from-primary to-destructive";
    if (corruption >= 300) return "from-chart-3 to-primary";
    if (corruption >= 100) return "from-chart-4 to-chart-3";
    return "from-chart-2 to-chart-4";
  };

  const getCorruptionMilestone = (corruption: number): { name: string; description: string } => {
    if (corruption >= 800) return { name: "Uber Endgame", description: "Maximum corruption pushing" };
    if (corruption >= 500) return { name: "High Corruption", description: "Uber Aberroth access" };
    if (corruption >= 300) return { name: "Mid Corruption", description: "Aberroth access" };
    if (corruption >= 100) return { name: "Early Corruption", description: "Woven Echoes unlock" };
    return { name: "Low Corruption", description: "Basic progression" };
  };

  const milestone = getCorruptionMilestone(targetCorruption);

  return (
    <div className="bg-card border border-border rounded-xl p-6 mb-6" data-testid="panel-corruption-calculator">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold">Corruption Calculator</h3>
        <i className="fas fa-calculator text-primary" data-testid="icon-calculator"></i>
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2" htmlFor="level-slider">
            Current Level
          </label>
          <input 
            id="level-slider"
            type="range" 
            min="90" 
            max="100" 
            value={playerLevel}
            onChange={(e) => onLevelChange(parseInt(e.target.value))}
            className="w-full accent-primary"
            data-testid="slider-player-level"
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>90</span>
            <span data-testid="text-current-level">{playerLevel}</span>
            <span>100</span>
          </div>
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-2" htmlFor="corruption-slider">
            Target Corruption
          </label>
          <input 
            id="corruption-slider"
            type="range" 
            min="0" 
            max="1000" 
            value={targetCorruption}
            step="50"
            onChange={(e) => onCorruptionChange(parseInt(e.target.value))}
            className="w-full accent-primary"
            data-testid="slider-target-corruption"
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>0</span>
            <span data-testid="text-current-corruption">{targetCorruption}</span>
            <span>1000+</span>
          </div>
        </div>
        
        <div 
          className={`corruption-bar w-full bg-gradient-to-r ${getCorruptionColor(targetCorruption)} h-2 rounded-full`}
          style={{ 
            background: `linear-gradient(90deg, hsl(var(--primary)) 0%, hsl(var(--destructive)) ${Math.min(100, targetCorruption / 10)}%)`
          }}
          data-testid="bar-corruption-progress"
        ></div>
        
        <div className="bg-accent/10 border border-accent/20 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium" data-testid="text-milestone-name">{milestone.name}</span>
            <span className="text-xs text-muted-foreground" data-testid="text-milestone-desc">{milestone.description}</span>
          </div>
          
          {isCalculating ? (
            <div className="flex items-center space-x-2" data-testid="loading-dps-calculation">
              <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              <span className="text-sm text-muted-foreground">Calculating requirements...</span>
            </div>
          ) : corruptionData ? (
            <div className="space-y-1">
              <p className="text-sm">
                <span className="text-muted-foreground">Recommended DPS:</span>
                <span className="text-primary font-bold ml-1" data-testid="text-recommended-dps">
                  {formatDPS(corruptionData.recommendedDPS)}
                </span>
              </p>
              <p className="text-sm">
                <span className="text-muted-foreground">Survival Threshold:</span>
                <span className="text-chart-2 font-bold ml-1" data-testid="text-survival-health">
                  {corruptionData.survivalThresholds?.health || "N/A"} HP
                </span>
              </p>
              {corruptionData.confidence && (
                <p className="text-xs text-muted-foreground">
                  AI Confidence: {corruptionData.confidence}%
                </p>
              )}
            </div>
          ) : (
            <p className="text-sm">
              <span className="text-muted-foreground">Recommended DPS:</span>
              <span className="text-primary font-bold ml-1" data-testid="text-fallback-dps">
                {formatDPS(800000 * Math.pow(1.03, targetCorruption))}
              </span>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
