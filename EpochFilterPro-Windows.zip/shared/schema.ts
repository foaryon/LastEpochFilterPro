import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Build definitions
export const builds = pgTable("builds", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  className: text("class_name").notNull(),
  mastery: text("mastery").notNull(),
  description: text("description").notNull(),
  playstyle: text("playstyle").notNull(),
  difficulty: text("difficulty").notNull(), // "Beginner", "Intermediate", "Advanced"
  tierRating: integer("tier_rating").notNull(), // 1 = S+, 2 = S, 3 = A+, etc.
  bossRating: text("boss_rating").notNull(),
  clearRating: text("clear_rating").notNull(),
  newbieRating: text("newbie_rating").notNull(),
  isNew: boolean("is_new").default(false),
  affixPriorities: jsonb("affix_priorities").$type<string[]>().notNull(),
  itemTypes: jsonb("item_types").$type<string[]>().notNull(),
  defenseRequirements: jsonb("defense_requirements").$type<{
    health: number;
    resistances: Record<string, number>;
    armor: number;
  }>().notNull(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

// Generated filters
export const generatedFilters = pgTable("generated_filters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  buildId: varchar("build_id").references(() => builds.id).notNull(),
  playerLevel: integer("player_level").notNull(),
  targetCorruption: integer("target_corruption").notNull(),
  filterRules: jsonb("filter_rules").$type<FilterRule[]>().notNull(),
  xmlContent: text("xml_content").notNull(),
  strictnessLevel: text("strictness_level").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

// Player characters
export const characters = pgTable("characters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  className: text("class_name").notNull(),
  mastery: text("mastery").notNull(),
  level: integer("level").notNull(),
  currentBuildId: varchar("current_build_id").references(() => builds.id),
  importedData: jsonb("imported_data").$type<CharacterImportData>(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
  lastAnalyzed: timestamp("last_analyzed").default(sql`now()`).notNull(),
});

// Character gear pieces
export const characterGear = pgTable("character_gear", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  characterId: varchar("character_id").references(() => characters.id).notNull(),
  slot: text("slot").notNull(), // "helmet", "body_armor", "weapon", etc.
  itemName: text("item_name").notNull(),
  itemType: text("item_type").notNull(),
  rarity: text("rarity").notNull(),
  affixes: jsonb("affixes").$type<GearAffix[]>().notNull(),
  totalAffixTiers: integer("total_affix_tiers").notNull(),
  weaknessScore: integer("weakness_score").notNull(), // 0-100, higher = weaker
  gapAnalysis: jsonb("gap_analysis").$type<GearGapAnalysis>(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

// Character idols
export const characterIdols = pgTable("character_idols", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  characterId: varchar("character_id").references(() => characters.id).notNull(),
  idolType: text("idol_type").notNull(), // "small", "large", "grand", etc.
  position: integer("position").notNull(), // position in idol grid
  affixes: jsonb("affixes").$type<GearAffix[]>().notNull(),
  totalAffixTiers: integer("total_affix_tiers").notNull(),
  weaknessScore: integer("weakness_score").notNull(),
  gapAnalysis: jsonb("gap_analysis").$type<IdolGapAnalysis>(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

// Personalized filters based on character analysis
export const personalizedFilters = pgTable("personalized_filters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  characterId: varchar("character_id").references(() => characters.id).notNull(),
  targetCorruption: integer("target_corruption").notNull(),
  prioritizedSlots: jsonb("prioritized_slots").$type<string[]>().notNull(), // weakest slots first
  filterRules: jsonb("filter_rules").$type<FilterRule[]>().notNull(),
  xmlContent: text("xml_content").notNull(),
  gapPriorities: jsonb("gap_priorities").$type<GapPriority[]>().notNull(),
  confidenceScore: integer("confidence_score").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

// AI analysis results
export const aiAnalysis = pgTable("ai_analysis", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  buildId: varchar("build_id").references(() => builds.id).notNull(),
  analysisType: text("analysis_type").notNull(), // "optimization", "discovery", "validation"
  confidence: integer("confidence").notNull(), // 0-100
  recommendations: jsonb("recommendations").$type<AIRecommendation[]>().notNull(),
  metadata: jsonb("metadata").$type<Record<string, any>>(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

// Users (extended from existing)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  preferences: jsonb("preferences").$type<UserPreferences>().default({}),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

// Type definitions
export type FilterRule = {
  id: string;
  type: "show" | "hide" | "highlight";
  conditions: {
    affixes?: { name: string; minTier: number }[];
    itemTypes?: string[];
    totalAffixTiers?: number;
    uniqueTypes?: string[];
    rarity?: "normal" | "magic" | "rare" | "unique" | "set" | "legendary";
  };
  color?: string;
  priority: number;
};

export type AIRecommendation = {
  type: "affix_priority" | "tier_threshold" | "item_focus" | "corruption_scaling";
  description: string;
  impact: "high" | "medium" | "low";
  confidence: number;
  data: Record<string, any>;
};

export type UserPreferences = {
  defaultStrictnessLevel?: "regular" | "strict" | "very_strict" | "uber_strict" | "giga_strict";
  faction?: "merchants_guild" | "circle_of_fortune";
  autoUpdateFilters?: boolean;
  preferredExportFormat?: "xml" | "json";
};

// Character import and analysis types
export type CharacterImportData = {
  gameVersion: string;
  characterStats: {
    health: number;
    mana?: number;
    ward?: number;
    armor: number;
    resistances: Record<string, number>;
    criticalStrikeAvoidance: number;
    attributes: {
      strength: number;
      dexterity: number;
      intelligence: number;
      vitality: number;
      attunement: number;
    };
  };
  importSource: "save_file" | "manual_input" | "api";
  importedAt: string;
};

export type GearAffix = {
  name: string;
  tier: number;
  value: number;
  maxValue: number;
  isPreffix: boolean;
  priority: "high" | "medium" | "low";
};

export type GearGapAnalysis = {
  optimalAffixes: string[];
  missingAffixes: string[];
  lowTierAffixes: { name: string; currentTier: number; targetTier: number }[];
  improvementPotential: number; // 0-100
  upgradeRecommendations: string[];
  estimatedUpgradeValue: number;
};

export type IdolGapAnalysis = {
  optimalAffixes: string[];
  currentEfficiency: number; // space utilization
  improvementSuggestions: string[];
  enchantmentPotential: boolean;
};

export type GapPriority = {
  slot: string;
  priority: number;
  reason: string;
  targetAffixes: string[];
  minTierThreshold: number;
};

// Zod schemas
export const insertBuildSchema = createInsertSchema(builds).omit({
  id: true,
  createdAt: true,
});

export const insertGeneratedFilterSchema = createInsertSchema(generatedFilters).omit({
  id: true,
  createdAt: true,
});

export const insertAiAnalysisSchema = createInsertSchema(aiAnalysis).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCharacterSchema = createInsertSchema(characters).omit({
  id: true,
  createdAt: true,
  lastAnalyzed: true,
});

export const insertCharacterGearSchema = createInsertSchema(characterGear).omit({
  id: true,
  createdAt: true,
});

export const insertCharacterIdolSchema = createInsertSchema(characterIdols).omit({
  id: true,
  createdAt: true,
});

export const insertPersonalizedFilterSchema = createInsertSchema(personalizedFilters).omit({
  id: true,
  createdAt: true,
});

// Inferred types
export type Build = typeof builds.$inferSelect;
export type InsertBuild = z.infer<typeof insertBuildSchema>;
export type GeneratedFilter = typeof generatedFilters.$inferSelect;
export type InsertGeneratedFilter = z.infer<typeof insertGeneratedFilterSchema>;
export type AIAnalysis = typeof aiAnalysis.$inferSelect;
export type InsertAIAnalysis = z.infer<typeof insertAiAnalysisSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Character = typeof characters.$inferSelect;
export type InsertCharacter = z.infer<typeof insertCharacterSchema>;
export type CharacterGear = typeof characterGear.$inferSelect;
export type InsertCharacterGear = z.infer<typeof insertCharacterGearSchema>;
export type CharacterIdol = typeof characterIdols.$inferSelect;
export type InsertCharacterIdol = z.infer<typeof insertCharacterIdolSchema>;
export type PersonalizedFilter = typeof personalizedFilters.$inferSelect;
export type InsertPersonalizedFilter = z.infer<typeof insertPersonalizedFilterSchema>;
