// Comprehensive Last Epoch Build Knowledge Base
// This contains deep, detailed information about every aspect of builds

export interface UniqueItem {
  name: string;
  slot: string;
  buildSynergy: string[];
  requiredLevel: number;
  legendaryPotential: number;
  criticalAffixes: string[];
  priority: 'core' | 'bis' | 'good' | 'alternative';
}

export interface IdolConfiguration {
  size: '1x1' | '2x1' | '1x2' | '2x2' | '3x1' | '1x3' | '4x1' | '1x4';
  prefix: string;
  suffix: string;
  priority: number;
  notes: string;
}

export interface AffixWeight {
  affix: string;
  weight: number;
  tierRequirement: number;
  scalingType: 'linear' | 'exponential' | 'breakpoint';
  breakpoints?: number[];
}

export interface BuildKnowledge {
  buildId: string;
  coreUniques: UniqueItem[];
  alternativeUniques: UniqueItem[];
  requiredIdols: IdolConfiguration[];
  affixWeights: AffixWeight[];
  skillRotation: string[];
  statPriority: string[];
  defensiveBreakpoints: {
    health: number[];
    armor: number[];
    resistanceCap: number;
    critAvoidance: number;
    enduranceThreshold: number;
  };
  offensiveBreakpoints: {
    critChance: number[];
    critMultiplier: number[];
    penetration: number[];
    attackSpeed: number[];
  };
}

// WARPATH VOID KNIGHT - Complete Build Knowledge
export const WARPATH_VK: BuildKnowledge = {
  buildId: 'warpath-void-knight',
  coreUniques: [
    {
      name: "Apathy's Maw",
      slot: "Two-Handed Sword",
      buildSynergy: ["void_damage", "melee_void_damage", "doom_chance"],
      requiredLevel: 85,
      legendaryPotential: 2,
      criticalAffixes: ["Melee Void Damage", "Void Penetration", "Critical Strike Multiplier"],
      priority: 'core'
    },
    {
      name: "Titan Heart",
      slot: "Body Armor",
      buildSynergy: ["health", "armor", "reduced_damage_taken"],
      requiredLevel: 80,
      legendaryPotential: 3,
      criticalAffixes: ["Health", "Armor", "Critical Strike Avoidance"],
      priority: 'bis'
    },
    {
      name: "Darkshround",
      slot: "Gloves",
      buildSynergy: ["armor_shred", "void_damage", "doom_application"],
      requiredLevel: 75,
      legendaryPotential: 2,
      criticalAffixes: ["Attack Speed", "Void Damage", "Health"],
      priority: 'good'
    }
  ],
  alternativeUniques: [
    {
      name: "Hollow Blade",
      slot: "Two-Handed Sword",
      buildSynergy: ["physical_to_void", "void_penetration"],
      requiredLevel: 70,
      legendaryPotential: 3,
      criticalAffixes: ["Melee Damage", "Void Damage", "Attack Speed"],
      priority: 'alternative'
    }
  ],
  requiredIdols: [
    {
      size: '2x2',
      prefix: "Increased Void Damage",
      suffix: "Chance to Shred Armor on Hit",
      priority: 1,
      notes: "Core idol for damage scaling"
    },
    {
      size: '1x3',
      prefix: "Vitality",
      suffix: "Increased Health",
      priority: 2,
      notes: "Defensive scaling"
    },
    {
      size: '1x2',
      prefix: "Increased Melee Damage",
      suffix: "Health on Melee Kill",
      priority: 3,
      notes: "Sustain while mapping"
    }
  ],
  affixWeights: [
    { affix: "Melee Void Damage", weight: 100, tierRequirement: 5, scalingType: 'exponential' },
    { affix: "Void Damage", weight: 90, tierRequirement: 5, scalingType: 'exponential' },
    { affix: "Critical Strike Multiplier", weight: 85, tierRequirement: 5, scalingType: 'linear' },
    { affix: "Void Penetration", weight: 80, tierRequirement: 4, scalingType: 'breakpoint', breakpoints: [30, 50, 75] },
    { affix: "Attack Speed", weight: 75, tierRequirement: 4, scalingType: 'linear' },
    { affix: "Health", weight: 70, tierRequirement: 5, scalingType: 'linear' },
    { affix: "Armor", weight: 65, tierRequirement: 4, scalingType: 'linear' },
    { affix: "Critical Strike Avoidance", weight: 60, tierRequirement: 4, scalingType: 'breakpoint', breakpoints: [60, 100] },
    { affix: "All Resistances", weight: 55, tierRequirement: 3, scalingType: 'breakpoint', breakpoints: [75] },
    { affix: "Movement Speed", weight: 50, tierRequirement: 3, scalingType: 'breakpoint', breakpoints: [30] }
  ],
  skillRotation: [
    "Anomaly (movement)",
    "Volatile Reversal (buffs)",
    "Warpath (channel)",
    "Doom Cleave (on echo proc)"
  ],
  statPriority: [
    "Void Damage",
    "Melee Damage",
    "Critical Strike Multiplier",
    "Attack Speed",
    "Health",
    "Armor",
    "Resistances"
  ],
  defensiveBreakpoints: {
    health: [2500, 3000, 3500, 4000],
    armor: [2000, 2500, 3000],
    resistanceCap: 75,
    critAvoidance: 100,
    enduranceThreshold: 60
  },
  offensiveBreakpoints: {
    critChance: [5, 30, 50],
    critMultiplier: [200, 300, 400],
    penetration: [30, 50, 75],
    attackSpeed: [0, 50, 100]
  }
};

// BALLISTA FALCONER - Zero HP Build
export const BALLISTA_FALCONER: BuildKnowledge = {
  buildId: 'ballista-falconer-zhp',
  coreUniques: [
    {
      name: "Talons of Valor",
      slot: "Gloves",
      buildSynergy: ["falcon_strike", "dive_bomb", "aerial_assault"],
      requiredLevel: 85,
      legendaryPotential: 2,
      criticalAffixes: ["Dexterity", "Attack Speed", "Critical Strike Chance"],
      priority: 'core'
    },
    {
      name: "Sinathia's Dying Breath",
      slot: "Bow",
      buildSynergy: ["detonating_arrow", "explosive_trap", "ballista"],
      requiredLevel: 82,
      legendaryPotential: 3,
      criticalAffixes: ["Bow Attack Speed", "Critical Strike Chance", "Dexterity"],
      priority: 'bis'
    },
    {
      name: "Exsanguinous",
      slot: "Body Armor",
      buildSynergy: ["zero_health", "ward_conversion"],
      requiredLevel: 16,
      legendaryPotential: 4,
      criticalAffixes: ["Intelligence", "Ward Retention", "Elemental Resistance"],
      priority: 'core'
    },
    {
      name: "Last Steps of the Living",
      slot: "Boots",
      buildSynergy: ["zero_health", "ward_per_missing_health"],
      requiredLevel: 5,
      legendaryPotential: 4,
      criticalAffixes: ["Movement Speed", "Ward per Second", "Hybrid Health"],
      priority: 'core'
    }
  ],
  alternativeUniques: [],
  requiredIdols: [
    {
      size: '3x1',
      prefix: "Chance for Ballista to use Explosive Arrows",
      suffix: "Increased Ballista Attack Speed",
      priority: 1,
      notes: "Mandatory for damage scaling"
    },
    {
      size: '2x2',
      prefix: "Ward per Second",
      suffix: "Ward Retention",
      priority: 2,
      notes: "Critical for ZHP survival"
    }
  ],
  affixWeights: [
    { affix: "Intelligence", weight: 100, tierRequirement: 7, scalingType: 'exponential' },
    { affix: "Ward per Second", weight: 95, tierRequirement: 6, scalingType: 'exponential' },
    { affix: "Ward Retention", weight: 90, tierRequirement: 5, scalingType: 'linear' },
    { affix: "Critical Strike Chance", weight: 85, tierRequirement: 5, scalingType: 'breakpoint', breakpoints: [75, 100] },
    { affix: "Bow Attack Speed", weight: 80, tierRequirement: 5, scalingType: 'linear' },
    { affix: "Dexterity", weight: 75, tierRequirement: 5, scalingType: 'linear' },
    { affix: "Elemental Resistance", weight: 70, tierRequirement: 4, scalingType: 'breakpoint', breakpoints: [75] }
  ],
  skillRotation: [
    "Smoke Bomb (positioning)",
    "Ballista (summon 4-5)",
    "Explosive Trap (debuff)",
    "Falcon Strike (movement)"
  ],
  statPriority: [
    "Intelligence (Ward scaling)",
    "Critical Strike Chance",
    "Attack Speed",
    "Ward per Second",
    "Ward Retention"
  ],
  defensiveBreakpoints: {
    health: [1], // Zero HP build
    armor: [0],
    resistanceCap: 75,
    critAvoidance: 0, // Not needed for ZHP
    enduranceThreshold: 0
  },
  offensiveBreakpoints: {
    critChance: [75, 85, 100],
    critMultiplier: [200, 250, 300],
    penetration: [0],
    attackSpeed: [50, 100, 150]
  }
};

// LIGHTNING BLAST RUNEMASTER
export const LIGHTNING_RUNEMASTER: BuildKnowledge = {
  buildId: 'lightning-blast-runemaster',
  coreUniques: [
    {
      name: "Prism Wraps",
      slot: "Gloves",
      buildSynergy: ["elemental_damage", "cast_speed", "lightning_damage"],
      requiredLevel: 85,
      legendaryPotential: 2,
      criticalAffixes: ["Cast Speed", "Lightning Damage", "Elemental Damage Over Time"],
      priority: 'bis'
    },
    {
      name: "Twisted Heart of Uhkeiros",
      slot: "Relic",
      buildSynergy: ["necrotic_to_lightning", "ward_generation"],
      requiredLevel: 90,
      legendaryPotential: 0,
      criticalAffixes: [],
      priority: 'core'
    }
  ],
  alternativeUniques: [
    {
      name: "Immolator's Oblation",
      slot: "Staff",
      buildSynergy: ["spell_damage", "fire_to_lightning"],
      requiredLevel: 75,
      legendaryPotential: 3,
      criticalAffixes: ["Spell Damage", "Cast Speed", "Lightning Penetration"],
      priority: 'alternative'
    }
  ],
  requiredIdols: [
    {
      size: '2x2',
      prefix: "Increased Lightning Damage",
      suffix: "Chance to Shock on Hit",
      priority: 1,
      notes: "Core damage scaling"
    },
    {
      size: '1x3',
      prefix: "Intelligence",
      suffix: "Ward per Second",
      priority: 2,
      notes: "Defensive layer"
    }
  ],
  affixWeights: [
    { affix: "Lightning Damage", weight: 100, tierRequirement: 6, scalingType: 'exponential' },
    { affix: "Spell Damage", weight: 95, tierRequirement: 5, scalingType: 'exponential' },
    { affix: "Cast Speed", weight: 90, tierRequirement: 5, scalingType: 'linear' },
    { affix: "Lightning Penetration", weight: 85, tierRequirement: 5, scalingType: 'breakpoint', breakpoints: [50, 75, 100] },
    { affix: "Spell Critical Strike Chance", weight: 80, tierRequirement: 5, scalingType: 'breakpoint', breakpoints: [40, 60, 75] },
    { affix: "Intelligence", weight: 75, tierRequirement: 5, scalingType: 'linear' },
    { affix: "Mana", weight: 70, tierRequirement: 4, scalingType: 'linear' },
    { affix: "Mana Regeneration", weight: 65, tierRequirement: 4, scalingType: 'linear' }
  ],
  skillRotation: [
    "Flame Rush (movement)",
    "Frost Wall (defense)",
    "Runic Invocation (buff)",
    "Lightning Blast (spam)"
  ],
  statPriority: [
    "Lightning Damage",
    "Spell Damage",
    "Cast Speed",
    "Critical Strike Chance",
    "Mana Regeneration"
  ],
  defensiveBreakpoints: {
    health: [2000, 2500, 3000],
    armor: [500, 1000],
    resistanceCap: 75,
    critAvoidance: 40,
    enduranceThreshold: 30
  },
  offensiveBreakpoints: {
    critChance: [40, 60, 75],
    critMultiplier: [200, 300, 400],
    penetration: [50, 75, 100],
    attackSpeed: [0] // Cast speed instead
  }
};

// Complete build knowledge database
export const BUILD_KNOWLEDGE_DB = new Map<string, BuildKnowledge>([
  ['warpath-void-knight', WARPATH_VK],
  ['ballista-falconer-zhp', BALLISTA_FALCONER],
  ['lightning-blast-runemaster', LIGHTNING_RUNEMASTER]
]);