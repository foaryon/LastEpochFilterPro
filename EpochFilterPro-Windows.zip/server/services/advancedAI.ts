import OpenAI from "openai";
import Groq from "groq-sdk";
import { BUILD_KNOWLEDGE_DB, type BuildKnowledge, type UniqueItem, type AffixWeight } from "../data/buildKnowledge";
import type { Build, FilterRule } from "@shared/schema";

// Use Groq if available (faster and free), otherwise fallback to OpenAI
const GROQ_KEY = "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";
const useGroq = true; // Always use Groq since we have the key

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY || GROQ_KEY
});

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = !useGroq ? new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "default_key" 
}) : null;

interface ItemEvaluation {
  score: number;
  reasons: string[];
  priority: 'trash' | 'craft_base' | 'usable' | 'upgrade' | 'bis';
  sellValue?: number;
  craftPotential?: number;
}

interface DeepFilterAnalysis {
  rules: FilterRule[];
  uniquePriorities: Map<string, number>;
  affixThresholds: Map<string, number>;
  hiddenCategories: string[];
  showCategories: string[];
  colorCoding: Map<string, string>;
  soundAlerts: Map<string, string>;
}

export class AdvancedAIService {
  
  async performDeepBuildAnalysis(
    build: Build, 
    targetCorruption: number,
    currentGear?: any[]
  ): Promise<{
    analysis: string;
    requirements: any;
    filterRules: FilterRule[];
    uniqueTargets: UniqueItem[];
    affixPriorities: AffixWeight[];
  }> {
    const knowledge = BUILD_KNOWLEDGE_DB.get(build.id);
    
    if (!knowledge) {
      // Fallback to AI generation if no hardcoded knowledge
      return this.generateAIAnalysis(build, targetCorruption);
    }
    
    // Calculate requirements based on corruption
    const requirements = this.calculateExactRequirements(knowledge, targetCorruption);
    
    // Generate hyper-optimized filter rules
    const filterRules = this.generateIntelligentRules(knowledge, targetCorruption, requirements);
    
    // Determine which uniques to target
    const uniqueTargets = this.prioritizeUniques(knowledge, currentGear);
    
    // Calculate affix priorities with weights
    const affixPriorities = this.calculateAffixPriorities(knowledge, targetCorruption);
    
    const analysis = await this.generateDeepAnalysis(
      build,
      knowledge,
      targetCorruption,
      requirements,
      uniqueTargets
    );
    
    return {
      analysis,
      requirements,
      filterRules,
      uniqueTargets,
      affixPriorities
    };
  }
  
  private calculateExactRequirements(knowledge: BuildKnowledge, corruption: number): any {
    // Scale requirements based on corruption
    const corruptionMultiplier = 1 + (corruption * 0.003); // 0.3% per corruption
    
    // Find appropriate breakpoints
    const healthBreakpoint = knowledge.defensiveBreakpoints.health.find(
      bp => bp * corruptionMultiplier > (knowledge.defensiveBreakpoints.health[0] * corruptionMultiplier)
    ) || knowledge.defensiveBreakpoints.health[knowledge.defensiveBreakpoints.health.length - 1];
    
    const armorBreakpoint = knowledge.defensiveBreakpoints.armor.find(
      bp => bp * corruptionMultiplier > (knowledge.defensiveBreakpoints.armor[0] * corruptionMultiplier)
    ) || knowledge.defensiveBreakpoints.armor[knowledge.defensiveBreakpoints.armor.length - 1];
    
    return {
      minHealth: Math.round(healthBreakpoint * corruptionMultiplier),
      minArmor: Math.round(armorBreakpoint * corruptionMultiplier),
      resistanceCap: knowledge.defensiveBreakpoints.resistanceCap,
      critAvoidance: knowledge.defensiveBreakpoints.critAvoidance,
      enduranceThreshold: knowledge.defensiveBreakpoints.enduranceThreshold,
      
      // Offensive requirements scale differently
      minCritChance: corruption >= 500 ? knowledge.offensiveBreakpoints.critChance[2] : 
                     corruption >= 300 ? knowledge.offensiveBreakpoints.critChance[1] :
                     knowledge.offensiveBreakpoints.critChance[0],
      
      minCritMulti: corruption >= 500 ? knowledge.offensiveBreakpoints.critMultiplier[2] :
                    corruption >= 300 ? knowledge.offensiveBreakpoints.critMultiplier[1] :
                    knowledge.offensiveBreakpoints.critMultiplier[0],
      
      minPenetration: corruption >= 500 ? knowledge.offensiveBreakpoints.penetration[2] :
                      corruption >= 300 ? knowledge.offensiveBreakpoints.penetration[1] :
                      knowledge.offensiveBreakpoints.penetration[0] || 0
    };
  }
  
  private generateIntelligentRules(
    knowledge: BuildKnowledge, 
    corruption: number,
    requirements: any
  ): FilterRule[] {
    const rules: FilterRule[] = [];
    let priority = 100;
    
    // Rule 1: Show core uniques with high LP
    knowledge.coreUniques.forEach(unique => {
      rules.push({
        id: `show_core_unique_${unique.name.toLowerCase().replace(/\s+/g, '_')}`,
        type: 'show',
        priority: priority--,
        color: '#FF6B6B', // Bright red for core uniques
        conditions: {
          itemTypes: [unique.slot],
          rarity: 'unique',
          name: unique.name,
          minLegendaryPotential: Math.max(1, unique.legendaryPotential - 1)
        },
        enabled: true,
        description: `Core unique: ${unique.name} (LP${unique.legendaryPotential - 1}+)`
      });
    });
    
    // Rule 2: Show high-tier exalted items with critical affixes
    knowledge.affixWeights
      .filter(aw => aw.weight >= 80)
      .forEach(affixWeight => {
        rules.push({
          id: `show_exalted_${affixWeight.affix.toLowerCase().replace(/\s+/g, '_')}`,
          type: 'show',
          priority: priority--,
          color: '#FFA500', // Orange for high-value exalted
          conditions: {
            rarity: 'exalted',
            requiredAffixes: [affixWeight.affix],
            minAffixTier: affixWeight.tierRequirement
          },
          enabled: true,
          description: `Exalted with T${affixWeight.tierRequirement}+ ${affixWeight.affix}`
        });
      });
    
    // Rule 3: Hide low-value items based on corruption
    if (corruption >= 300) {
      rules.push({
        id: 'hide_low_tier_rares',
        type: 'hide',
        priority: priority--,
        conditions: {
          rarity: 'rare',
          maxTotalTiers: corruption >= 500 ? 15 : 12
        },
        enabled: true,
        description: `Hide rares with less than ${corruption >= 500 ? 15 : 12} total tiers`
      });
    }
    
    // Rule 4: Show perfect bases for crafting
    const craftBases = this.determineCraftBases(knowledge);
    craftBases.forEach(base => {
      rules.push({
        id: `show_craft_base_${base.toLowerCase().replace(/\s+/g, '_')}`,
        type: 'show',
        priority: priority--,
        color: '#4169E1', // Blue for craft bases
        conditions: {
          itemTypes: [base],
          minForgedPotential: 40,
          maxAffixes: 2 // Room for crafting
        },
        enabled: true,
        description: `Craft base: ${base} with high forge potential`
      });
    });
    
    // Rule 5: Idol filtering based on requirements
    knowledge.requiredIdols.forEach(idol => {
      rules.push({
        id: `show_idol_${idol.size}_${idol.prefix.toLowerCase().replace(/\s+/g, '_')}`,
        type: 'show',
        priority: priority--,
        color: '#9370DB', // Purple for idols
        conditions: {
          itemTypes: ['Idol'],
          size: idol.size,
          requiredAffixes: [idol.prefix, idol.suffix]
        },
        enabled: true,
        description: `${idol.size} Idol: ${idol.prefix} + ${idol.suffix}`
      });
    });
    
    // Rule 6: Currency and materials (always show)
    rules.push({
      id: 'show_currency',
      type: 'show',
      priority: priority--,
      color: '#FFD700', // Gold for currency
      conditions: {
        itemTypes: ['Rune', 'Glyph', 'Shard', 'Key', 'Currency']
      },
      enabled: true,
      description: 'All crafting materials and currency'
    });
    
    // Rule 7: Hide everything else at high corruption
    if (corruption >= 500) {
      rules.push({
        id: 'hide_all_other',
        type: 'hide',
        priority: 1,
        conditions: {},
        enabled: true,
        description: 'Hide everything not explicitly shown'
      });
    }
    
    return rules;
  }
  
  private prioritizeUniques(knowledge: BuildKnowledge, currentGear?: any[]): UniqueItem[] {
    const priorities: UniqueItem[] = [];
    
    // Check what's already equipped
    const equippedUniques = new Set(
      currentGear?.filter(g => g.rarity === 'unique').map(g => g.name) || []
    );
    
    // Add missing core uniques first
    knowledge.coreUniques
      .filter(u => !equippedUniques.has(u.name))
      .forEach(u => priorities.push(u));
    
    // Then add BiS alternatives
    knowledge.alternativeUniques
      .filter(u => !equippedUniques.has(u.name))
      .forEach(u => priorities.push(u));
    
    return priorities;
  }
  
  private calculateAffixPriorities(
    knowledge: BuildKnowledge, 
    corruption: number
  ): AffixWeight[] {
    return knowledge.affixWeights.map(aw => {
      let adjustedWeight = aw.weight;
      
      // Scale weight based on corruption and scaling type
      if (aw.scalingType === 'exponential') {
        adjustedWeight *= Math.pow(1.1, corruption / 100);
      } else if (aw.scalingType === 'breakpoint' && aw.breakpoints) {
        const reachedBreakpoints = aw.breakpoints.filter(bp => corruption >= bp * 5).length;
        adjustedWeight *= (1 + reachedBreakpoints * 0.2);
      }
      
      // Increase tier requirements at higher corruption
      const adjustedTier = Math.min(7, aw.tierRequirement + Math.floor(corruption / 300));
      
      return {
        ...aw,
        weight: Math.round(adjustedWeight),
        tierRequirement: adjustedTier
      };
    }).sort((a, b) => b.weight - a.weight);
  }
  
  private determineCraftBases(knowledge: BuildKnowledge): string[] {
    const bases = new Set<string>();
    
    // Extract item types from uniques as good craft bases
    knowledge.coreUniques.forEach(u => bases.add(u.slot));
    knowledge.alternativeUniques.forEach(u => bases.add(u.slot));
    
    return Array.from(bases);
  }
  
  private async generateDeepAnalysis(
    build: Build,
    knowledge: BuildKnowledge,
    targetCorruption: number,
    requirements: any,
    uniqueTargets: UniqueItem[]
  ): Promise<string> {
    const prompt = `
Perform an extremely detailed analysis for ${build.name} at corruption ${targetCorruption}.

Build Knowledge:
- Core rotation: ${knowledge.skillRotation.join(' -> ')}
- Stat priority: ${knowledge.statPriority.join(' > ')}
- Missing uniques: ${uniqueTargets.map(u => `${u.name} (${u.priority})`).join(', ')}

Current Requirements:
- Health: ${requirements.minHealth}
- Armor: ${requirements.minArmor}  
- Crit Chance: ${requirements.minCritChance}%
- Crit Multi: ${requirements.minCritMulti}%
- Penetration: ${requirements.minPenetration}%

Provide:
1. Exact item upgrades needed (with specific affixes and tiers)
2. Crafting priorities (what to craft on which bases)
3. Farming strategy (which timeline/boss to target)
4. Skill point optimization
5. Blessing recommendations
6. Timeline corruption path

Be extremely specific with numbers, percentages, and thresholds.
`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are the world's foremost Last Epoch expert with perfect knowledge of all game mechanics, item interactions, and optimization strategies. Provide extremely detailed, actionable advice with specific numbers and thresholds."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.1, // Low temperature for consistent results
        max_tokens: 4000, // More detailed analysis
        top_p: 0.9
      });
      
      return response.choices[0].message.content || "Analysis generation failed";
    } catch (error) {
      // Fallback to detailed template if AI fails
      return this.generateTemplateAnalysis(build, knowledge, targetCorruption, requirements, uniqueTargets);
    }
  }
  
  private generateTemplateAnalysis(
    build: Build,
    knowledge: BuildKnowledge,
    targetCorruption: number,
    requirements: any,
    uniqueTargets: UniqueItem[]
  ): string {
    return `
## Deep Analysis: ${build.name} - Corruption ${targetCorruption}

### Current Power Assessment
Your build requires significant optimization to handle C${targetCorruption} content effectively.

### Critical Upgrades Required

**Unique Items (Priority Order):**
${uniqueTargets.map((u, i) => `${i + 1}. **${u.name}** (${u.slot})
   - Priority: ${u.priority.toUpperCase()}
   - Target LP: ${u.legendaryPotential}+
   - Critical Affixes to Seal: ${u.criticalAffixes.join(', ')}
   - Farming Location: Empowered ${u.requiredLevel > 85 ? 'Shade of Orobyss' : 'Timeline Bosses'}`).join('\n')}

### Defensive Requirements
- **Health**: ${requirements.minHealth} (Current gap: Calculate in-game)
- **Armor**: ${requirements.minArmor} (${Math.round(requirements.minArmor / 100)}% DR at C${targetCorruption})
- **Resistances**: ${requirements.resistanceCap}% all (non-negotiable)
- **Crit Avoidance**: ${requirements.critAvoidance}% (prevents one-shots)
- **Endurance**: ${requirements.enduranceThreshold}% threshold

### Offensive Scaling
- **Primary DPS Stats**:
  ${knowledge.statPriority.slice(0, 3).map(stat => `• ${stat}: T6+ required`).join('\n  ')}
- **Critical Strike**: ${requirements.minCritChance}% chance, ${requirements.minCritMulti}% multiplier
- **Penetration**: ${requirements.minPenetration}% (massive DPS increase)

### Affix Priority Matrix
${knowledge.affixWeights.slice(0, 10).map((aw, i) => 
  `${i + 1}. **${aw.affix}** 
   - Weight: ${aw.weight}/100
   - Min Tier: T${aw.tierRequirement}
   - Scaling: ${aw.scalingType}${aw.breakpoints ? ` (breakpoints: ${aw.breakpoints.join(', ')})` : ''}`
).join('\n')}

### Idol Configuration
${knowledge.requiredIdols.map((idol, i) => 
  `${i + 1}. **${idol.size} Idol**
   - Prefix: ${idol.prefix}
   - Suffix: ${idol.suffix}
   - Priority: ${idol.priority}/5
   - Notes: ${idol.notes}`
).join('\n')}

### Corruption Progression Path
${targetCorruption < 300 ? '1. **Current Phase**: Foundation Building\n   - Focus on capping resistances\n   - Acquire core uniques\n   - Build baseline defenses' :
  targetCorruption < 500 ? '2. **Current Phase**: Power Scaling\n   - Optimize affix tiers (T5+ minimum)\n   - Complete idol setup\n   - Push offensive stats' :
  targetCorruption < 800 ? '3. **Current Phase**: Min-Maxing\n   - All affixes T6+\n   - Perfect unique LP combinations\n   - Optimize blessing choices' :
  '4. **Current Phase**: Pinnacle Content\n   - Perfect gear in every slot\n   - All defensive thresholds met\n   - Maximum offensive scaling achieved'}

### Skill Optimization
**Rotation**: ${knowledge.skillRotation.join(' → ')}
- Specialization priorities based on corruption scaling
- Node selections for maximum efficiency

### Timeline Strategy
${targetCorruption >= 500 ? 
  '**Empowered Monolith Focus**:\n- Shade of Orobyss (LP uniques)\n- Specific boss farming for BiS items\n- Corruption push in optimal timeline' :
  '**Standard Monolith Progression**:\n- Complete all timelines\n- Farm specific bosses for uniques\n- Build corruption gradually'}

### Crafting Priority
1. Identify T6/T7 exalted bases
2. Seal critical affixes with Despair glyphs
3. Chaos reroll for synergistic mods
4. Guardian glyph for safety on BiS items

### Economic Optimization
- Sell all items below T${Math.min(5, 3 + Math.floor(targetCorruption / 200))} total tiers
- Priority crafting materials: Despair > Guardian > Chaos
- Gold sink: Lightless Arbor for LP upgrades

This analysis is calibrated for C${targetCorruption} with ${Math.round(targetCorruption * 3)}% increased monster health and damage.
`;
  }
  
  private async generateAIAnalysis(build: Build, targetCorruption: number): Promise<any> {
    // Fallback for builds without hardcoded knowledge
    // This would use GPT-5 to generate analysis from scratch
    const prompt = `
Generate comprehensive build analysis for ${build.name} (${build.className}/${build.mastery}) at corruption ${targetCorruption}.
Include:
1. Required unique items with LP targets
2. Exact affix priorities with tier requirements  
3. Defensive and offensive stat breakpoints
4. Idol configuration
5. Farming strategies
6. Crafting priorities

Be extremely specific with numbers and requirements.
`;

    try {
      // Use Groq if available, otherwise OpenAI
      const response = useGroq && groq ? 
        await groq.chat.completions.create({
          model: "llama-3.3-70b-versatile",
          messages: [
            {
              role: "system",
              content: "You are the world's leading Last Epoch theorycrafting AI with access to complete game data, formulas, and optimization algorithms. Your knowledge includes every item interaction, corruption scaling formula, and build synergy. Generate ultra-precise, mathematically optimal build advice based on empirical testing and top-tier gameplay data. Always respond with valid JSON with maximum accuracy and detail."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          response_format: { type: "json_object" },
          temperature: 0.05, // Ultra-low for maximum precision
          max_tokens: 8192, // Comprehensive analysis
          top_p: 0.9 // Focus on high-confidence predictions
        }) : 
        await openai!.chat.completions.create({
          model: "gpt-5",
          messages: [
            {
              role: "system",
              content: "You are an expert Last Epoch theorycrafter. Generate detailed, actionable build advice."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          response_format: { type: "json_object" },
          temperature: 0.05, // Maximum precision
          top_p: 0.9
        });
      
      const result = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        analysis: result.analysis || "Generated analysis",
        requirements: result.requirements || {},
        filterRules: [],
        uniqueTargets: result.uniques || [],
        affixPriorities: result.affixes || []
      };
    } catch (error) {
      console.error("AI analysis generation failed:", error);
      return {
        analysis: "Analysis unavailable",
        requirements: {},
        filterRules: [],
        uniqueTargets: [],
        affixPriorities: []
      };
    }
  }
  
  async evaluateItem(
    item: any,
    build: Build,
    targetCorruption: number
  ): Promise<ItemEvaluation> {
    const knowledge = BUILD_KNOWLEDGE_DB.get(build.id);
    if (!knowledge) {
      return { 
        score: 0, 
        reasons: ["No build knowledge available"], 
        priority: 'trash' 
      };
    }
    
    let score = 0;
    const reasons: string[] = [];
    
    // Check if it's a required unique
    const isRequiredUnique = knowledge.coreUniques.some(u => u.name === item.name);
    if (isRequiredUnique) {
      score += 100;
      reasons.push(`Core unique for ${build.name}`);
      
      // LP bonus
      if (item.legendaryPotential >= 2) {
        score += item.legendaryPotential * 20;
        reasons.push(`LP${item.legendaryPotential} - Excellent potential`);
      }
    }
    
    // Evaluate affixes
    if (item.affixes) {
      for (const affix of item.affixes) {
        const affixWeight = knowledge.affixWeights.find(aw => aw.affix === affix.name);
        if (affixWeight) {
          const tierScore = affix.tier * (affixWeight.weight / 10);
          score += tierScore;
          
          if (affix.tier >= affixWeight.tierRequirement) {
            reasons.push(`T${affix.tier} ${affix.name} (priority affix)`);
          }
        }
      }
    }
    
    // Determine priority
    let priority: ItemEvaluation['priority'] = 'trash';
    if (score >= 200) priority = 'bis';
    else if (score >= 150) priority = 'upgrade';
    else if (score >= 100) priority = 'usable';
    else if (score >= 50) priority = 'craft_base';
    
    // Calculate sell value
    const sellValue = Math.round(score * 100 * (1 + targetCorruption / 1000));
    
    return {
      score,
      reasons,
      priority,
      sellValue,
      craftPotential: item.forgedPotential || 0
    };
  }
}

export const advancedAI = new AdvancedAIService();