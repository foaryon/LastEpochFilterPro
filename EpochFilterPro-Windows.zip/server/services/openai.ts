import OpenAI from "openai";
import type { Build, FilterRule, AIRecommendation } from "@shared/schema";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export interface FilterGenerationRequest {
  build: Build;
  playerLevel: number;
  targetCorruption: number;
  faction: "merchants_guild" | "circle_of_fortune";
  strictnessLevel: "regular" | "strict" | "very_strict" | "uber_strict" | "giga_strict";
}

export interface FilterGenerationResponse {
  rules: FilterRule[];
  xmlContent: string;
  recommendations: AIRecommendation[];
  confidence: number;
}

export class AIFilterService {
  async generateOptimalFilter(request: FilterGenerationRequest): Promise<FilterGenerationResponse> {
    const prompt = this.buildFilterPrompt(request);
    
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are an expert Last Epoch theorycrafting AI with comprehensive knowledge of Season 3 mechanics, corruption scaling, affix optimization, and loot filter creation. Generate optimal loot filters based on build requirements and progression targets."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return this.processAIResponse(result, request);
    } catch (error) {
      console.error("OpenAI API error:", error);
      throw new Error(`AI filter generation failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async discoverNewBuilds(communityData: string[]): Promise<{ builds: Partial<Build>[], confidence: number }> {
    const prompt = `
Analyze the following Last Epoch community data sources and identify potential S-tier builds that may not be in the current meta database.

Community Data Sources:
${communityData.join('\n')}

Your task:
1. Identify builds with high performance indicators
2. Validate build viability through multiple source cross-reference
3. Assess S-tier potential based on boss killing, clear speed, and survivability
4. Only recommend builds that appear in multiple sources with positive feedback

Return a JSON response with:
{
  "builds": [
    {
      "name": "string",
      "className": "string",
      "mastery": "string", 
      "description": "string",
      "playstyle": "string",
      "confidence": number,
      "sources": ["string"],
      "performance_indicators": {
        "boss_rating": "string",
        "clear_rating": "string", 
        "popularity_score": number
      }
    }
  ],
  "overall_confidence": number
}`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system", 
            content: "You are an expert Last Epoch build analyst with access to comprehensive game knowledge and community insights. Only recommend builds that show genuine S-tier potential."
          },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return {
        builds: result.builds || [],
        confidence: result.overall_confidence || 0
      };
    } catch (error) {
      console.error("Build discovery error:", error);
      throw new Error(`Build discovery failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async calculateCorruptionRequirements(build: Build, targetCorruption: number): Promise<{
    recommendedDPS: number;
    survivalThresholds: Record<string, number>;
    gearRequirements: string[];
    confidence: number;
  }> {
    const prompt = `
Calculate precise damage and survival requirements for ${build.name} at ${targetCorruption} corruption in Last Epoch Season 3.

Build Details:
- Class/Mastery: ${build.className}/${build.mastery}
- Playstyle: ${build.playstyle}
- Known Affix Priorities: ${build.affixPriorities.join(', ')}

Corruption Scaling Mechanics to Consider:
- Monster health increases ~3% per corruption level
- Monster damage increases ~2.5% per corruption level  
- Player needs to maintain consistent clear speed
- Boss fights become exponentially more dangerous
- Defensive thresholds become critical at 300+ corruption

Calculate and return JSON:
{
  "recommendedDPS": number (in raw DPS),
  "survivalThresholds": {
    "health": number,
    "resistances": number,
    "armor": number,
    "criticalStrikeAvoidance": number
  },
  "gearRequirements": ["specific T6/T7 affixes needed"],
  "confidence": number (0-100),
  "reasoning": "string explaining calculations"
}`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are a Last Epoch mathematics expert specializing in corruption scaling calculations and build optimization. Use precise game mechanics and scaling formulas."
          },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.1
      });

      return JSON.parse(response.choices[0].message.content || "{}");
    } catch (error) {
      console.error("Corruption calculation error:", error);
      throw new Error(`Corruption calculations failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private buildFilterPrompt(request: FilterGenerationRequest): string {
    const { build, playerLevel, targetCorruption, faction, strictnessLevel } = request;
    
    return `
Generate an optimal Last Epoch loot filter for the following specifications:

BUILD INFORMATION:
- Name: ${build.name}
- Class/Mastery: ${build.className}/${build.mastery}
- Playstyle: ${build.playstyle}
- Description: ${build.description}
- Priority Affixes: ${build.affixPriorities.join(', ')}
- Item Types: ${build.itemTypes.join(', ')}

PLAYER PROGRESSION:
- Current Level: ${playerLevel}
- Target Corruption: ${targetCorruption}
- Faction: ${faction}
- Strictness Level: ${strictnessLevel}

FILTER REQUIREMENTS:
1. Progressive strictness based on corruption level
2. Prioritize build-relevant affixes with proper tier thresholds
3. Include idol optimization rules
4. Handle Legendary Potential (LP) items appropriately
5. Optimize for ${faction === 'merchants_guild' ? 'trading value' : 'personal progression'}
6. Account for Season 3 Primordial items and mechanics

STRICTNESS LEVEL GUIDANCE:
- regular: Show most relevant gear, T4+ affixes
- strict: T5+ affixes, hide low-tier items
- very_strict: T6+ affixes, strict idol rules
- uber_strict: T6+ required, hide T6 exalteds, only double T6+ shown
- giga_strict: Only T7s, triple+ exalteds, perfect bases

Return a comprehensive JSON response with:
{
  "rules": [
    {
      "id": "string",
      "type": "show|hide|highlight", 
      "conditions": {
        "affixes": [{"name": "string", "minTier": number}],
        "itemTypes": ["string"],
        "totalAffixTiers": number,
        "uniqueTypes": ["string"],
        "rarity": "string"
      },
      "color": "string",
      "priority": number
    }
  ],
  "xmlContent": "string (valid Last Epoch XML filter format)",
  "recommendations": [
    {
      "type": "string",
      "description": "string", 
      "impact": "high|medium|low",
      "confidence": number,
      "data": {}
    }
  ],
  "confidence": number (0-100)
}

Ensure the XML follows proper Last Epoch filter syntax with correct rule ordering and valid condition statements.`;
  }

  private processAIResponse(aiResponse: any, request: FilterGenerationRequest): FilterGenerationResponse {
    // Validate and process AI response
    const rules: FilterRule[] = aiResponse.rules || [];
    const xmlContent: string = aiResponse.xmlContent || this.generateFallbackXML(request);
    const recommendations: AIRecommendation[] = aiResponse.recommendations || [];
    const confidence: number = Math.max(0, Math.min(100, aiResponse.confidence || 70));

    return {
      rules,
      xmlContent,
      recommendations,
      confidence
    };
  }

  private generateFallbackXML(request: FilterGenerationRequest): string {
    // Fallback XML generation if AI fails
    return `<?xml version="1.0" encoding="utf-8"?>
<lootfilter>
  <rule>
    <name>Hide All (Base)</name>
    <hide>true</hide>
  </rule>
  <rule>
    <name>Show Build Relevant - ${request.build.name}</name>
    <itemtype>${request.build.itemTypes.join(' ')}</itemtype>
    <color>255 255 255</color>
  </rule>
</lootfilter>`;
  }
}

export const aiFilterService = new AIFilterService();
