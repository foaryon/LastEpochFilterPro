import { memo } from "react";

interface AIStatusPanelProps {
  isLoading: boolean;
  filterData?: any;
}

const AIStatusPanel = memo(function AIStatusPanel({ isLoading, filterData }: AIStatusPanelProps) {
  return (
    <div className="gothic-border rounded-xl p-6 mb-8 mystical-glow" data-testid="panel-ai-status">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center">
          <i className="fas fa-robot gold-text mr-2" data-testid="icon-robot"></i>
          <span className="metallic-text">AI Filter Generator Status</span>
        </h2>
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${isLoading ? 'bg-chart-3 animate-pulse' : 'bg-chart-2'}`}></div>
          <span className="text-sm font-medium text-chart-2" data-testid="text-ai-mode">
            {isLoading ? 'Processing...' : 'Autonomous Mode'}
          </span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="item-frame-normal rounded-lg p-4" data-testid="card-build-discovery">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Build Discovery</p>
              <p className="text-lg font-bold">12/12 Active</p>
            </div>
            <i className="fas fa-search gold-text text-xl" data-testid="icon-search"></i>
          </div>
        </div>
        
        <div className="item-frame-normal rounded-lg p-4" data-testid="card-filter-optimization">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Filter Optimization</p>
              <p className="text-lg font-bold">
                {isLoading ? 'Processing...' : 'Real-time'}
              </p>
            </div>
            <i className="fas fa-filter gold-text text-xl" data-testid="icon-filter"></i>
          </div>
        </div>
        
        <div className="item-frame-normal rounded-lg p-4" data-testid="card-learning-progress">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Learning Progress</p>
              <p className="text-lg font-bold">
                {filterData?.confidence ? `${filterData.confidence}%` : '87%'} Complete
              </p>
            </div>
            <i className="fas fa-graduation-cap gold-text text-xl" data-testid="icon-graduation"></i>
          </div>
        </div>
      </div>

      {filterData && (
        <div className="mt-4 parchment rounded-lg" data-testid="panel-ai-analysis-results">
          <h4 className="font-semibold mb-2 flex items-center text-chart-2">
            <i className="fas fa-check-circle mr-2"></i>
            AI Analysis Results
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Enhancement Level:</p>
              <p className="font-medium">{filterData.aiEnhanced ? 'AI Enhanced' : 'Progressive Generation'}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Confidence Score:</p>
              <p className="font-medium">{filterData.confidence}%</p>
            </div>
            <div>
              <p className="text-muted-foreground">Filter Rules:</p>
              <p className="font-medium">{filterData.rules?.length || 0} rules generated</p>
            </div>
            <div>
              <p className="text-muted-foreground">Strictness Level:</p>
              <p className="font-medium capitalize">{filterData.strictnessLevel?.replace('_', ' ')}</p>
            </div>
          </div>
          
          {filterData.recommendations?.length > 0 && (
            <div className="mt-3 pt-3 border-t border-chart-2/20">
              <p className="text-sm font-medium mb-2">AI Recommendations:</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                {filterData.recommendations.slice(0, 3).map((rec: any, index: number) => (
                  <li key={index} className="flex items-start space-x-1">
                    <span className="text-chart-2">•</span>
                    <span>{rec.description}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}, (prevProps, nextProps) => {
  return prevProps.isLoading === nextProps.isLoading &&
         JSON.stringify(prevProps.filterData) === JSON.stringify(nextProps.filterData);
});

export default AIStatusPanel;
