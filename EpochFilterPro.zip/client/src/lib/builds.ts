import type { Build } from "@shared/schema";

// Build utility functions and constants
export const CLASS_COLORS: Record<string, string> = {
  "Sentinel": "#E53E3E", // Red
  "Rogue": "#38A169", // Green  
  "Acolyte": "#805AD5", // Purple
  "Primalist": "#D69E2E", // Yellow
  "Mage": "#3182CE", // Blue
};

export const MASTERY_ICONS: Record<string, string> = {
  "Paladin": "fas fa-shield-alt",
  "Void Knight": "fas fa-skull",
  "Forge Guard": "fas fa-hammer",
  "Marksman": "fas fa-crosshairs",
  "Blade Dancer": "fas fa-wind",
  "Falconer": "fas fa-feather-alt",
  "Necromancer": "fas fa-skull-crossbones",
  "Lich": "fas fa-magic",
  "Warlock": "fas fa-fire",
  "Beastmaster": "fas fa-paw",
  "Shaman": "fas fa-bolt",
  "Druid": "fas fa-leaf",
  "Sorcerer": "fas fa-snowflake",
  "Spellblade": "fas fa-sword",
  "Runemaster": "fas fa-language",
};

export function getBuildColor(build: Build): string {
  return CLASS_COLORS[build.className] || "#4A5568";
}

export function getMasteryIcon(mastery: string): string {
  return MASTERY_ICONS[mastery] || "fas fa-star";
}

export function formatBuildName(build: Build): string {
  return `${build.name} (${build.mastery})`;
}

export function getBuildTierName(tierRating: number): string {
  switch (tierRating) {
    case 1: return "S+";
    case 2: return "S";
    case 3: return "A+";
    case 4: return "A";
    default: return "B+";
  }
}

export function getBuildDifficultyColor(difficulty: string): string {
  switch (difficulty.toLowerCase()) {
    case "beginner": return "text-chart-2";
    case "intermediate": return "text-chart-3"; 
    case "advanced": return "text-destructive";
    default: return "text-muted-foreground";
  }
}

export function filterBuildsBySearch(builds: Build[], searchTerm: string): Build[] {
  const term = searchTerm.toLowerCase().trim();
  if (!term) return builds;
  
  return builds.filter(build => 
    build.name.toLowerCase().includes(term) ||
    build.className.toLowerCase().includes(term) ||
    build.mastery.toLowerCase().includes(term) ||
    build.description.toLowerCase().includes(term) ||
    build.playstyle.toLowerCase().includes(term)
  );
}

export function sortBuildsByTier(builds: Build[]): Build[] {
  return [...builds].sort((a, b) => {
    // First sort by tier rating (lower = better)
    if (a.tierRating !== b.tierRating) {
      return a.tierRating - b.tierRating;
    }
    
    // Then prioritize new builds
    if (a.isNew !== b.isNew) {
      return a.isNew ? -1 : 1;
    }
    
    // Finally sort alphabetically
    return a.name.localeCompare(b.name);
  });
}

export function getBuildsByClass(builds: Build[]): Record<string, Build[]> {
  return builds.reduce((acc, build) => {
    if (!acc[build.className]) {
      acc[build.className] = [];
    }
    acc[build.className].push(build);
    return acc;
  }, {} as Record<string, Build[]>);
}

export function getPopularBuilds(builds: Build[], limit: number = 6): Build[] {
  return sortBuildsByTier(builds).slice(0, limit);
}

export function getNewBuilds(builds: Build[]): Build[] {
  return builds.filter(build => build.isNew);
}

export function validateBuildSelection(build: Build | null): { valid: boolean; message?: string } {
  if (!build) {
    return { valid: false, message: "Please select a build" };
  }
  
  if (!build.affixPriorities.length) {
    return { valid: false, message: "Build is missing affix priorities" };
  }
  
  if (!build.itemTypes.length) {
    return { valid: false, message: "Build is missing item type configuration" };
  }
  
  return { valid: true };
}
