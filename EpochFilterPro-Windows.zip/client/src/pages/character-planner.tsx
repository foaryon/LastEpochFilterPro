import { useState } from "react";
import CharacterPlanner from "../components/CharacterPlanner";
import Navigation from "../components/Navigation";

export default function CharacterPlannerPage() {
  const [generatedFilter, setGeneratedFilter] = useState<any>(null);

  const handleFilterGenerated = (filterData: any) => {
    setGeneratedFilter(filterData);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-chart-2 to-primary bg-clip-text text-transparent">
            Character Planner
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Import your Last Epoch characters and generate personalized loot filters that target your weakest gear pieces for optimal progression.
          </p>
        </div>

        {/* Character Planner Component */}
        <div className="max-w-6xl mx-auto">
          <CharacterPlanner onFilterGenerated={handleFilterGenerated} />
        </div>

        {/* Generated Filter Display */}
        {generatedFilter && (
          <div className="max-w-6xl mx-auto mt-8">
            <div className="bg-accent/10 border border-accent/30 rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-primary">
                    Personalized Filter Generated!
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Filter for {generatedFilter.characterName} - Targeting weakest gear slots
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="text-right">
                    <div className="text-lg font-bold text-chart-2">{generatedFilter.confidenceScore}%</div>
                    <div className="text-xs text-muted-foreground">Confidence</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2">Priority Slots (Weakest First)</h4>
                  <div className="flex flex-wrap gap-1">
                    {generatedFilter.prioritizedSlots.map((slot: string, index: number) => (
                      <span 
                        key={slot}
                        className={`px-2 py-1 text-xs rounded ${
                          index === 0 ? 'bg-destructive text-destructive-foreground' :
                          index === 1 ? 'bg-chart-3 text-white' :
                          'bg-secondary text-secondary-foreground'
                        }`}
                      >
                        #{index + 1} {slot.replace('_', ' ')}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-sm mb-2">Filter Rules</h4>
                  <div className="text-sm text-muted-foreground">
                    {generatedFilter.rules.length} personalized rules generated
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Target Corruption: {generatedFilter.metadata.targetCorruption}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div className="text-sm text-muted-foreground">
                  Generated at {new Date(generatedFilter.metadata.generatedAt).toLocaleString()}
                </div>
                <button
                  onClick={() => {
                    const blob = new Blob([generatedFilter.xmlContent], { type: 'application/xml' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${generatedFilter.characterName.replace(/\s+/g, '_')}_personalized_C${generatedFilter.metadata.targetCorruption}.xml`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                  }}
                  className="bg-primary text-primary-foreground px-4 py-2 rounded hover:bg-primary/90 text-sm font-medium transition-colors"
                  data-testid="button-download-personalized-filter"
                >
                  <i className="fas fa-download mr-2"></i>
                  Download Filter
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}