// Corruption mechanics and calculations
export interface CorruptionTier {
  min: number;
  max: number;
  name: string;
  description: string;
  color: string;
  unlocks: string[];
}

export const CORRUPTION_TIERS: CorruptionTier[] = [
  {
    min: 0,
    max: 99,
    name: "Low Corruption",
    description: "Basic progression and gear acquisition",
    color: "#38A169", // Green
    unlocks: ["Timeline progression", "Basic empowered echoes"]
  },
  {
    min: 100,
    max: 299, 
    name: "Early Corruption",
    description: "Woven Echoes unlock, increased rewards",
    color: "#D69E2E", // Yellow
    unlocks: ["Woven Echoes", "Enhanced item drops", "First corruption bonuses"]
  },
  {
    min: 300,
    max: 499,
    name: "Mid Corruption", 
    description: "Aberroth access, serious scaling begins",
    color: "#E53E3E", // Red
    unlocks: ["Aberroth encounters", "High-tier gear drops", "Major scaling challenges"]
  },
  {
    min: 500,
    max: 799,
    name: "High Corruption",
    description: "Uber Aberroth access, extreme difficulty",
    color: "#9F7AEA", // Purple
    unlocks: ["Uber Aberroth", "Perfect gear requirements", "Maximum challenge"]
  },
  {
    min: 800,
    max: 1000,
    name: "Uber Endgame", 
    description: "Ultimate corruption pushing territory",
    color: "#F56565", // Bright red
    unlocks: ["Leaderboard competition", "Perfect optimization required"]
  }
];

export function getCorruptionTier(corruption: number): CorruptionTier {
  return CORRUPTION_TIERS.find(tier => 
    corruption >= tier.min && corruption <= tier.max
  ) || CORRUPTION_TIERS[0];
}

export function calculateMonsterHealthMultiplier(corruption: number): number {
  // ~3% health increase per corruption level
  return 1 + (corruption * 0.03);
}

export function calculateMonsterDamageMultiplier(corruption: number): number {
  // ~2.5% damage increase per corruption level  
  return 1 + (corruption * 0.025);
}

export function calculateRecommendedDPS(
  baseDPS: number, 
  corruption: number,
  buildMultiplier: number = 1.0
): number {
  const healthMultiplier = calculateMonsterHealthMultiplier(corruption);
  return Math.round(baseDPS * buildMultiplier * healthMultiplier);
}

export function calculateDefensiveRequirements(
  baseHealth: number,
  baseArmor: number,
  corruption: number
): { health: number; armor: number; resistances: number } {
  const damageMultiplier = calculateMonsterDamageMultiplier(corruption);
  
  return {
    health: Math.round(baseHealth * (1 + corruption * 0.002)), // 0.2% health per corruption
    armor: Math.round(baseArmor * (1 + corruption * 0.0015)), // 0.15% armor per corruption  
    resistances: 75 // Always max resistances
  };
}

export function getCorruptionMilestones(): number[] {
  return [100, 200, 300, 500, 800];
}

export function getNextMilestone(currentCorruption: number): number | null {
  const milestones = getCorruptionMilestones();
  return milestones.find(milestone => milestone > currentCorruption) || null;
}

export function calculateCorruptionProgress(
  currentCorruption: number,
  targetCorruption: number
): { percentage: number; remaining: number; tier: CorruptionTier } {
  const percentage = Math.min(100, (currentCorruption / targetCorruption) * 100);
  const remaining = Math.max(0, targetCorruption - currentCorruption);
  const tier = getCorruptionTier(currentCorruption);
  
  return { percentage, remaining, tier };
}

export function formatCorruption(corruption: number): string {
  if (corruption >= 1000) {
    return `${(corruption / 1000).toFixed(1)}K`;
  }
  return corruption.toString();
}

export function getCorruptionColor(corruption: number): string {
  const tier = getCorruptionTier(corruption);
  return tier.color;
}

export function isCorruptionViable(
  corruption: number,
  playerLevel: number,
  hasEndgameGear: boolean
): { viable: boolean; warnings: string[] } {
  const warnings: string[] = [];
  
  if (playerLevel < 90 && corruption > 0) {
    warnings.push("Corruption not available until level 90+ empowered monoliths");
  }
  
  if (corruption > 300 && !hasEndgameGear) {
    warnings.push("High corruption requires T6+ gear and proper defensive layers");
  }
  
  if (corruption > 500 && playerLevel < 100) {
    warnings.push("Uber corruption typically requires level 100 optimization");
  }
  
  const viable = warnings.length === 0;
  return { viable, warnings };
}

export function getStrictnessForCorruption(corruption: number): string {
  if (corruption >= 800) return "giga_strict";
  if (corruption >= 500) return "uber_strict";
  if (corruption >= 300) return "very_strict";
  if (corruption >= 100) return "strict";
  return "regular";
}
