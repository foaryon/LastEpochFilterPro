import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { aiFilterService } from "./services/openai";
import { groqFilterService } from "./services/groq";
import { advancedAI } from "./services/advancedAI";
import { buildAnalyzer } from "./services/buildAnalyzer";
import { filterGenerator } from "./services/filterGenerator";
import { characterAnalyzer } from "./services/characterAnalyzer";
import { z } from "zod";
import { buildCache, filterCache } from "./utils/cache";

// Request validation schemas
const generateFilterSchema = z.object({
  buildId: z.string(),
  playerLevel: z.number().min(90).max(100),
  targetCorruption: z.number().min(0).max(1000),
  faction: z.enum(["merchants_guild", "circle_of_fortune"]).default("merchants_guild"),
  strictnessLevel: z.enum(["regular", "strict", "very_strict", "uber_strict", "giga_strict"]).optional()
});

const corruptionCalculationSchema = z.object({
  buildId: z.string(),
  targetCorruption: z.number().min(0).max(1000)
});

const characterImportSchema = z.object({
  name: z.string(),
  className: z.string(),
  mastery: z.string(),
  level: z.number().min(1).max(100),
  stats: z.object({
    health: z.number(),
    armor: z.number(),
    resistances: z.record(z.number()),
    criticalStrikeAvoidance: z.number()
  }).optional(),
  attributes: z.object({
    strength: z.number(),
    dexterity: z.number(),
    intelligence: z.number(),
    vitality: z.number(),
    attunement: z.number()
  }).optional(),
  importSource: z.enum(["save_file", "manual_input", "api"]).default("manual_input")
});

const personalizedFilterSchema = z.object({
  characterId: z.string(),
  targetCorruption: z.number().min(0).max(1000)
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Character import endpoint
  app.post("/api/character/import", async (req, res) => {
    try {
      const validatedData = characterImportSchema.parse(req.body);
      const character = await storage.createCharacter(validatedData);
      res.json({ character });
    } catch (error) {
      console.error("Error importing character:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid character data", details: error.errors });
      } else {
        res.status(500).json({ 
          error: "Failed to import character", 
          message: error instanceof Error ? error.message : String(error) 
        });
      }
    }
  });
  
  // Get all characters
  app.get("/api/characters", async (req, res) => {
    try {
      const characters = await storage.getCharacters();
      res.json({ characters });
    } catch (error) {
      console.error("Error fetching characters:", error);
      res.status(500).json({ 
        error: "Failed to fetch characters", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  // AI build analysis endpoint with deep analysis
  app.post("/api/ai/analyze-build", async (req, res) => {
    try {
      const { buildId, analysis, targetCorruption = 500 } = req.body;
      const build = buildAnalyzer.getBuildById(buildId);
      if (!build) {
        return res.status(404).json({ error: "Build not found" });
      }
      
      // Perform deep AI analysis
      const deepAnalysis = await advancedAI.performDeepBuildAnalysis(
        build,
        targetCorruption
      );
      
      const recommendations = buildAnalyzer.analyzeAffixPriority(build, targetCorruption);
      
      res.json({ 
        buildId, 
        analysis,
        recommendations,
        deepAnalysis: {
          detailedAnalysis: deepAnalysis.analysis,
          requirements: deepAnalysis.requirements,
          uniqueTargets: deepAnalysis.uniqueTargets,
          affixPriorities: deepAnalysis.affixPriorities,
          filterRules: deepAnalysis.filterRules
        }
      });
    } catch (error) {
      console.error("Error analyzing build:", error);
      res.status(500).json({ 
        error: "Failed to analyze build", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  // AI build discovery endpoint
  app.get("/api/ai/discover-builds", async (req, res) => {
    try {
      const newBuilds = buildAnalyzer.getNewBuilds();
      res.json({ 
        builds: newBuilds,
        confidence: 85,
        message: "Discovered " + newBuilds.length + " new S-tier builds from community data"
      });
    } catch (error) {
      console.error("Error discovering builds:", error);
      res.status(500).json({ 
        error: "Failed to discover builds", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  // Corruption calculation endpoint
  app.post("/api/corruption/calculate", async (req, res) => {
    try {
      const validatedData = corruptionCalculationSchema.parse(req.body);
      const { buildId, targetCorruption } = validatedData;
      
      const build = buildAnalyzer.getBuildById(buildId);
      if (!build) {
        return res.status(404).json({ error: "Build not found" });
      }
      
      const damageReq = filterGenerator.calculateDamageRequirement(build, targetCorruption);
      const progression = buildAnalyzer.calculateOptimalProgression(build, 100);
      
      res.json({ 
        buildId,
        targetCorruption,
        requiredDamage: damageReq,
        progression,
        scalingFactor: Math.pow(1.03, targetCorruption)
      });
    } catch (error) {
      console.error("Error calculating corruption:", error);
      res.status(500).json({ 
        error: "Failed to calculate corruption requirements", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  // Get all available builds with caching
  app.get("/api/builds", async (req, res) => {
    try {
      // Check cache first
      const cacheKey = 'all-builds';
      let builds = buildCache.get(cacheKey);
      
      if (!builds) {
        builds = buildAnalyzer.getAllBuilds();
        buildCache.set(cacheKey, builds);
      }
      
      res.json({ builds });
    } catch (error) {
      console.error("Error fetching builds:", error);
      res.status(500).json({ 
        error: "Failed to fetch builds", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Get specific build by ID with caching
  app.get("/api/builds/:id", async (req, res) => {
    try {
      const cacheKey = `build-${req.params.id}`;
      let build = buildCache.get(cacheKey);
      
      if (!build) {
        build = buildAnalyzer.getBuildById(req.params.id);
        if (!build) {
          return res.status(404).json({ error: "Build not found" });
        }
        buildCache.set(cacheKey, build);
      }
      
      res.json({ build });
    } catch (error) {
      console.error("Error fetching build:", error);
      res.status(500).json({ 
        error: "Failed to fetch build", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Get builds by class
  app.get("/api/builds/class/:className", async (req, res) => {
    try {
      const builds = buildAnalyzer.getBuildsByClass(req.params.className);
      res.json({ builds });
    } catch (error) {
      console.error("Error fetching builds by class:", error);
      res.status(500).json({ 
        error: "Failed to fetch builds by class", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Get new builds (Season 3 additions)
  app.get("/api/builds/new", async (req, res) => {
    try {
      const cacheKey = 'new-builds';
      let builds = buildCache.get(cacheKey);
      
      if (!builds) {
        builds = buildAnalyzer.getNewBuilds();
        buildCache.set(cacheKey, builds);
      }
      
      res.json({ builds });
    } catch (error) {
      console.error("Error fetching new builds:", error);
      res.status(500).json({ 
        error: "Failed to fetch new builds", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Generate AI-optimized filter with deep analysis
  app.post("/api/generate-filter", async (req, res) => {
    try {
      const validatedData = generateFilterSchema.parse(req.body);
      const { buildId, playerLevel, targetCorruption, faction, strictnessLevel } = validatedData;
      
      const build = buildAnalyzer.getBuildById(buildId);
      if (!build) {
        return res.status(404).json({ error: "Build not found" });
      }

      // Perform deep AI analysis
      const deepAnalysis = await advancedAI.performDeepBuildAnalysis(
        build,
        targetCorruption
      );
      
      // Generate progressive filter first
      const progressiveResult = filterGenerator.generateProgressiveFilter(
        build, 
        playerLevel, 
        targetCorruption, 
        faction
      );

      // Enhance with AI analysis if API key is available
      let aiEnhanced = false;
      let aiRecommendations: any[] = [];
      let confidence = 85; // Base confidence for progressive filter
      let xmlContent = progressiveResult.xmlContent; // Initialize with progressive filter XML

      try {
        // Use Groq (API key is configured)
        if (true) { // Groq API key is hardcoded
          const aiResult = await groqFilterService.generateOptimalFilter({
            build,
            playerLevel,
            targetCorruption,
            faction,
            strictnessLevel: strictnessLevel || "regular"
          });
          
          // Update the progressive result with AI-generated content
          progressiveResult.xmlContent = aiResult.xmlContent;
          confidence = aiResult.confidence;
          aiEnhanced = true;
          aiRecommendations = aiResult.recommendations || [];
        } else if (process.env.OPENAI_API_KEY) {
          const aiResult = await aiFilterService.generateOptimalFilter({
            build,
            playerLevel,
            targetCorruption,
            faction,
            strictnessLevel: strictnessLevel || progressiveResult.strictnessLevel as any
          });
          
          aiEnhanced = true;
          aiRecommendations = aiResult.recommendations;
          confidence = aiResult.confidence;
          
          // Merge AI recommendations with progressive filter
          progressiveResult.xmlContent = aiResult.xmlContent;
        }
      } catch (aiError) {
        console.warn("AI enhancement failed, using progressive filter:", aiError instanceof Error ? aiError.message : String(aiError));
      }

      // Store generated filter
      const generatedFilter = await storage.createGeneratedFilter({
        buildId,
        playerLevel,
        targetCorruption,
        filterRules: progressiveResult.rules,
        xmlContent: progressiveResult.xmlContent,
        strictnessLevel: progressiveResult.strictnessLevel
      });

      res.json({
        filterId: generatedFilter.id,
        buildName: build.name,
        rules: deepAnalysis.filterRules.length > 0 ? deepAnalysis.filterRules : progressiveResult.rules,
        xmlContent: progressiveResult.xmlContent,
        strictnessLevel: progressiveResult.strictnessLevel,
        aiEnhanced,
        recommendations: aiRecommendations,
        confidence,
        deepAnalysis: {
          analysis: deepAnalysis.analysis,
          requirements: deepAnalysis.requirements,
          uniqueTargets: deepAnalysis.uniqueTargets,
          affixPriorities: deepAnalysis.affixPriorities
        },
        metadata: {
          playerLevel,
          targetCorruption,
          faction,
          generatedAt: new Date().toISOString()
        }
      });

    } catch (error) {
      console.error("Error generating filter:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Invalid request data", 
          details: error.errors 
        });
      }
      res.status(500).json({ 
        error: "Failed to generate filter", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Calculate corruption scaling requirements
  app.post("/api/calculate-corruption", async (req, res) => {
    try {
      const validatedData = corruptionCalculationSchema.parse(req.body);
      const { buildId, targetCorruption } = validatedData;
      
      const build = buildAnalyzer.getBuildById(buildId);
      if (!build) {
        return res.status(404).json({ error: "Build not found" });
      }

      // Calculate damage requirements
      const recommendedDPS = filterGenerator.calculateDamageRequirement(build, targetCorruption);
      
      // Calculate defense scaling
      const defenseMultiplier = 1 + (targetCorruption * 0.002);
      const scaledDefenses = {
        health: Math.round(build.defenseRequirements.health * defenseMultiplier),
        resistances: 75, // Always cap resistances
        armor: Math.round(build.defenseRequirements.armor * defenseMultiplier)
      };

      // Analyze affix priorities for this corruption level
      const affixRecommendations = buildAnalyzer.analyzeAffixPriority(build, targetCorruption);

      // Enhanced AI calculation if available
      let aiEnhanced = false;
      let aiCalculations = null;

      try {
        // Use Groq (API key is configured)
        if (true) { // Groq API key is hardcoded
          aiCalculations = await groqFilterService.calculateCorruptionRequirements(build, targetCorruption);
          aiEnhanced = true;
        } else if (process.env.OPENAI_API_KEY) {
          aiCalculations = await aiFilterService.calculateCorruptionRequirements(build, targetCorruption);
          aiEnhanced = true;
        }
      } catch (aiError) {
        console.warn("AI corruption calculation failed:", aiError instanceof Error ? aiError.message : String(aiError));
      }

      res.json({
        buildId,
        buildName: build.name,
        targetCorruption,
        recommendedDPS: aiCalculations?.recommendedDPS || recommendedDPS,
        survivalThresholds: aiCalculations?.survivalThresholds || scaledDefenses,
        gearRequirements: aiCalculations?.gearRequirements || [
          `T${targetCorruption >= 500 ? '7' : '6'}+ primary affixes`,
          `${scaledDefenses.health}+ health`,
          "75% all resistances",
          `${scaledDefenses.armor}+ armor`
        ],
        affixRecommendations,
        aiEnhanced,
        confidence: aiCalculations?.confidence || 80,
        metadata: {
          defenseMultiplier,
          calculatedAt: new Date().toISOString()
        }
      });

    } catch (error) {
      console.error("Error calculating corruption requirements:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Invalid request data", 
          details: error.errors 
        });
      }
      res.status(500).json({ 
        error: "Failed to calculate corruption requirements", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Get AI analysis for a build
  app.get("/api/builds/:id/analysis", async (req, res) => {
    try {
      const build = buildAnalyzer.getBuildById(req.params.id);
      if (!build) {
        return res.status(404).json({ error: "Build not found" });
      }

      const analysis = await storage.getAIAnalysisForBuild(req.params.id);
      const progression = buildAnalyzer.calculateOptimalProgression(build, 95);

      res.json({
        buildId: req.params.id,
        analysis,
        progression,
        lastUpdated: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error fetching build analysis:", error);
      res.status(500).json({ 
        error: "Failed to fetch build analysis", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Export filter as downloadable file
  app.get("/api/filters/:filterId/export", async (req, res) => {
    try {
      const filter = await storage.getGeneratedFilterById(req.params.filterId);
      if (!filter) {
        return res.status(404).json({ error: "Filter not found" });
      }

      const build = buildAnalyzer.getBuildById(filter.buildId);
      const filename = `${build?.name.replace(/\s+/g, '_') || 'filter'}_C${filter.targetCorruption}_L${filter.playerLevel}.xml`;

      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'application/xml');
      res.send(filter.xmlContent);

    } catch (error) {
      console.error("Error exporting filter:", error);
      res.status(500).json({ 
        error: "Failed to export filter", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // AI build discovery (background task)
  app.post("/api/ai/discover-builds", async (req, res) => {
    try {
      // Groq API key is configured in the code
      if (false) { // We always have Groq now
        return res.status(503).json({ 
          error: "AI service unavailable", 
          message: "No AI API key configured (Groq or OpenAI)" 
        });
      }

      // Mock community data sources (in real implementation, this would web scrape)
      const mockCommunityData = [
        "Recent Maxroll.gg tier list updates",
        "LastEpochTools.com build submissions", 
        "Community Reddit discussions",
        "YouTube build guides analysis"
      ];

      // Use Groq (API key is configured)
      const discoveryResult = true ? // Always use Groq 
        await groqFilterService.discoverNewBuilds(mockCommunityData) :
        await aiFilterService.discoverNewBuilds(mockCommunityData);

      res.json({
        discovered: discoveryResult.builds.length,
        confidence: discoveryResult.confidence,
        builds: discoveryResult.builds,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error in AI build discovery:", error);
      res.status(500).json({ 
        error: "Build discovery failed", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Character Import and Analysis Routes
  
  // Get all characters
  app.get("/api/characters", async (req, res) => {
    try {
      const characters = await storage.getAllCharacters();
      res.json({ characters });
    } catch (error) {
      console.error("Error fetching characters:", error);
      res.status(500).json({ 
        error: "Failed to fetch characters", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Get specific character with gear and idols
  app.get("/api/characters/:id", async (req, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ error: "Character not found" });
      }

      const [gear, idols] = await Promise.all([
        storage.getCharacterGear(req.params.id),
        storage.getCharacterIdols(req.params.id)
      ]);

      res.json({ character, gear, idols });
    } catch (error) {
      console.error("Error fetching character:", error);
      res.status(500).json({ 
        error: "Failed to fetch character", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Import character data
  app.post("/api/characters/import", async (req, res) => {
    try {
      const validatedData = characterImportSchema.parse(req.body);
      
      // Import and analyze character data
      const importResult = await characterAnalyzer.importCharacterData(validatedData, validatedData.importSource);
      
      // Create character record
      const character = await storage.createCharacter(importResult.character);
      
      // Find matching build
      const matchedBuildId = await characterAnalyzer.matchCharacterToBuild(character);
      if (matchedBuildId) {
        await storage.updateCharacter(character.id, { currentBuildId: matchedBuildId });
      }

      // Create gear records
      const gearPromises = importResult.gear.map(gearData =>
        storage.createCharacterGear({ ...gearData, characterId: character.id })
      );
      const gear = await Promise.all(gearPromises);

      // Create idol records
      const idolPromises = importResult.idols.map(idolData =>
        storage.createCharacterIdol({ ...idolData, characterId: character.id })
      );
      const idols = await Promise.all(idolPromises);

      res.json({
        character: { ...character, currentBuildId: matchedBuildId },
        gear,
        idols,
        confidence: importResult.confidence,
        message: "Character imported successfully"
      });

    } catch (error) {
      console.error("Error importing character:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Invalid character data", 
          details: error.errors 
        });
      }
      res.status(500).json({ 
        error: "Failed to import character", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Analyze character gaps
  app.post("/api/characters/:id/analyze", async (req, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ error: "Character not found" });
      }

      if (!character.currentBuildId) {
        return res.status(400).json({ error: "Character must have an associated build for analysis" });
      }

      const build = buildAnalyzer.getBuildById(character.currentBuildId);
      if (!build) {
        return res.status(400).json({ error: "Associated build not found" });
      }

      const [gear, idols] = await Promise.all([
        storage.getCharacterGear(req.params.id),
        storage.getCharacterIdols(req.params.id)
      ]);

      const gapAnalysis = await characterAnalyzer.analyzeCharacterGaps(character, gear, idols, build);
      
      // Update character last analyzed timestamp
      await storage.updateCharacter(req.params.id, { lastAnalyzed: new Date() });

      res.json({
        characterId: req.params.id,
        buildName: build.name,
        gapAnalysis,
        analyzedAt: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error analyzing character:", error);
      res.status(500).json({ 
        error: "Failed to analyze character", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Generate personalized filter
  app.post("/api/characters/personalized-filter", async (req, res) => {
    try {
      const validatedData = personalizedFilterSchema.parse(req.body);
      const { characterId, targetCorruption } = validatedData;
      
      const character = await storage.getCharacter(characterId);
      if (!character) {
        return res.status(404).json({ error: "Character not found" });
      }

      if (!character.currentBuildId) {
        return res.status(400).json({ error: "Character must have an associated build" });
      }

      const build = buildAnalyzer.getBuildById(character.currentBuildId);
      if (!build) {
        return res.status(400).json({ error: "Associated build not found" });
      }

      const [gear, idols] = await Promise.all([
        storage.getCharacterGear(characterId),
        storage.getCharacterIdols(characterId)
      ]);

      // Perform gap analysis
      const gapAnalysis = await characterAnalyzer.analyzeCharacterGaps(character, gear, idols, build);
      
      // Generate personalized filter
      const personalizedFilter = await characterAnalyzer.generatePersonalizedFilter(
        character,
        gapAnalysis,
        targetCorruption
      );

      // Store the personalized filter
      const savedFilter = await storage.createPersonalizedFilter({
        characterId,
        targetCorruption,
        prioritizedSlots: gapAnalysis.weakestSlots,
        filterRules: personalizedFilter.rules,
        xmlContent: personalizedFilter.xmlContent,
        gapPriorities: personalizedFilter.priorities,
        confidenceScore: Math.round(gapAnalysis.overallScore)
      });

      res.json({
        filterId: savedFilter.id,
        characterName: character.name,
        buildName: build.name,
        rules: personalizedFilter.rules,
        xmlContent: personalizedFilter.xmlContent,
        gapAnalysis,
        prioritizedSlots: gapAnalysis.weakestSlots,
        confidenceScore: Math.round(gapAnalysis.overallScore),
        metadata: {
          targetCorruption,
          generatedAt: new Date().toISOString(),
          personalized: true
        }
      });

    } catch (error) {
      console.error("Error generating personalized filter:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Invalid request data", 
          details: error.errors 
        });
      }
      res.status(500).json({ 
        error: "Failed to generate personalized filter", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Export personalized filter
  app.get("/api/personalized-filters/:filterId/export", async (req, res) => {
    try {
      const filter = await storage.getPersonalizedFilter(req.params.filterId, 0); // TODO: Fix this lookup
      if (!filter) {
        return res.status(404).json({ error: "Personalized filter not found" });
      }

      const character = await storage.getCharacter(filter.characterId);
      const filename = `${character?.name.replace(/\s+/g, '_') || 'character'}_personalized_C${filter.targetCorruption}.xml`;

      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'application/xml');
      res.send(filter.xmlContent);

    } catch (error) {
      console.error("Error exporting personalized filter:", error);
      res.status(500).json({ 
        error: "Failed to export personalized filter", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Deep item evaluation endpoint
  app.post("/api/ai/evaluate-item", async (req, res) => {
    try {
      const { item, buildId, targetCorruption } = req.body;
      
      const build = buildAnalyzer.getBuildById(buildId);
      if (!build) {
        return res.status(404).json({ error: "Build not found" });
      }
      
      const evaluation = await advancedAI.evaluateItem(
        item,
        build,
        targetCorruption || 300
      );
      
      res.json(evaluation);
    } catch (error) {
      console.error("Error evaluating item:", error);
      res.status(500).json({ 
        error: "Failed to evaluate item", 
        message: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
