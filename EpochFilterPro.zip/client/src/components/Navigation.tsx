import { Link, useLocation } from "wouter";
import { Button } from "./ui/button";

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50 gothic-border stone-texture">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-2">
              <i className="fas fa-filter text-2xl gold-text" data-testid="logo-icon"></i>
              <h1 className="text-xl font-bold metallic-text">
                EpochFilterPro
              </h1>
            </div>
            <div className="hidden md:block text-sm text-muted-foreground">
              AI-Powered Last Epoch Season 3 Filter Creator
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center space-x-4">
            {/* Main Filter Forge */}
            <div className="flex items-center space-x-2 mr-8">
              <Link href="/">
                <Button
                  variant={location === "/" ? "default" : "ghost"}
                  className={location === "/" ? "bg-primary text-primary-foreground neon-glow" : "btn-gothic"}
                  data-testid="nav-filter-forge"
                >
                  <i className="fas fa-magic mr-2"></i>
                  Filter Forge
                </Button>
              </Link>
            </div>

            {/* Separator */}
            <div className="w-px h-6 bg-border"></div>

            {/* Character Tools Section */}
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground font-medium hidden md:inline">Character Tools:</span>
              <Link href="/character-planner">
                <Button
                  variant={location === "/character-planner" ? "default" : "outline"}
                  className={location === "/character-planner" ? "bg-secondary text-secondary-foreground mystical-glow" : "btn-gothic border-secondary/30 hover:mystical-glow"}
                  data-testid="nav-character-planner"
                >
                  <i className="fas fa-user-cog mr-2"></i>
                  Character Planner
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <div className="md:hidden mt-3 flex flex-wrap items-center gap-2">
          <Link href="/">
            <Button
              size="sm"
              variant={location === "/" ? "default" : "ghost"}
              data-testid="nav-mobile-filter-forge"
            >
              <i className="fas fa-magic mr-1"></i>
              Filter Forge
            </Button>
          </Link>
          <Link href="/character-planner">
            <Button
              size="sm"
              variant={location === "/character-planner" ? "default" : "outline"}
              className={location === "/character-planner" ? "bg-chart-2 text-white" : "border-chart-2/30 text-chart-2"}
              data-testid="nav-mobile-character-planner"
            >
              <i className="fas fa-user-cog mr-1"></i>
              Character Planner
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  );
}