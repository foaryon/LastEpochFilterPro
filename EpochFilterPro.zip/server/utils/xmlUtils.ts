import type { FilterRule } from "@shared/schema";

/**
 * Converts hex color to RGB values
 */
export function hexToRGB(hex: string): { r: number; g: number; b: number } {
  const cleanHex = hex.replace('#', '');
  return {
    r: parseInt(cleanHex.substr(0, 2), 16),
    g: parseInt(cleanHex.substr(2, 2), 16),
    b: parseInt(cleanHex.substr(4, 2), 16)
  };
}

/**
 * Converts a filter rule to XML format
 */
export function ruleToXML(rule: FilterRule | any): string {
  let xml = `  <rule>\n    <name>${rule.id}</name>\n`;
  
  if (rule.type === "hide") {
    xml += `    <hide>true</hide>\n`;
  } else {
    xml += `    <show>true</show>\n`;
  }

  if (rule.color) {
    const { r, g, b } = hexToRGB(rule.color);
    xml += `    <color>${r} ${g} ${b}</color>\n`;
  }

  // Add conditions
  if (rule.conditions?.itemTypes?.length) {
    xml += `    <itemtype>${rule.conditions.itemTypes.join(' ')}</itemtype>\n`;
  }

  if (rule.conditions?.rarity) {
    xml += `    <rarity>${rule.conditions.rarity}</rarity>\n`;
  }

  xml += `  </rule>`;
  return xml;
}

/**
 * Generates XML header for loot filter
 */
export function generateXMLHeader(metadata: {
  buildName?: string;
  characterName?: string;
  playerLevel?: number;
  targetCorruption?: number;
  strictnessLevel?: string;
}): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<!-- Last Epoch Loot Filter -->
${metadata.buildName ? `<!-- Build: ${metadata.buildName} -->` : ''}
${metadata.characterName ? `<!-- Character: ${metadata.characterName} -->` : ''}
${metadata.playerLevel ? `<!-- Player Level: ${metadata.playerLevel} -->` : ''}
${metadata.targetCorruption ? `<!-- Target Corruption: ${metadata.targetCorruption} -->` : ''}
${metadata.strictnessLevel ? `<!-- Strictness: ${metadata.strictnessLevel} -->` : ''}
<!-- Generated: ${new Date().toISOString()} -->
<lootfilter>`;
}

/**
 * Generates XML footer for loot filter
 */
export function generateXMLFooter(): string {
  return `</lootfilter>`;
}

/**
 * Calculates strictness level based on corruption
 */
export function calculateStrictnessLevel(targetCorruption: number): string {
  if (targetCorruption >= 800) return "giga_strict";
  if (targetCorruption >= 500) return "uber_strict";
  if (targetCorruption >= 300) return "very_strict";
  if (targetCorruption >= 100) return "strict";
  return "regular";
}

/**
 * Formats large numbers for display
 */
export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  } else if (num >= 1000) {
    return `${(num / 1000).toFixed(0)}K`;
  }
  return num.toString();
}