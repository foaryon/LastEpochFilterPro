import type { 
  Character, 
  CharacterGear, 
  CharacterIdol, 
  Build, 
  GearAffix, 
  GearGapAnalysis, 
  IdolGapAnalysis,
  GapPriority,
  PersonalizedFilter
} from "@shared/schema";
import { aiFilterService } from "./openai";
import { buildAnalyzer } from "./buildAnalyzer";
import { ruleToXML, generateXMLHeader, generateXMLFooter } from "../utils/xmlUtils";

export interface CharacterImportResult {
  character: Omit<Character, 'id' | 'createdAt' | 'lastAnalyzed'>;
  gear: Omit<CharacterGear, 'id' | 'characterId' | 'createdAt'>[];
  idols: Omit<CharacterIdol, 'id' | 'characterId' | 'createdAt'>[];
  confidence: number;
}

export interface GapAnalysisResult {
  overallScore: number;
  weakestSlots: string[];
  prioritizedUpgrades: GapPriority[];
  improvementPotential: number;
  recommendations: string[];
}

export class CharacterAnalyzer {
  
  async importCharacterData(importData: any, importSource: string): Promise<CharacterImportResult> {
    // This would parse different import formats (save files, JSON, manual input)
    // For now, implementing a mock structure that demonstrates the concept
    
    const mockCharacter = {
      name: importData.name || "Imported Character",
      className: importData.className || "Sentinel",
      mastery: importData.mastery || "Void Knight", 
      level: importData.level || 95,
      currentBuildId: null, // Will be matched later
      importedData: {
        gameVersion: "1.3.0",
        characterStats: {
          health: importData.stats?.health || 2800,
          armor: importData.stats?.armor || 2000,
          resistances: importData.stats?.resistances || {
            Fire: 75, Cold: 75, Lightning: 75, Necrotic: 75, Void: 75
          },
          criticalStrikeAvoidance: importData.stats?.criticalStrikeAvoidance || 85,
          attributes: {
            strength: importData.attributes?.strength || 120,
            dexterity: importData.attributes?.dexterity || 45,
            intelligence: importData.attributes?.intelligence || 30,
            vitality: importData.attributes?.vitality || 180,
            attunement: importData.attributes?.attunement || 25
          }
        },
        importSource: importSource as any,
        importedAt: new Date().toISOString()
      }
    };

    const mockGear: Omit<CharacterGear, 'id' | 'characterId' | 'createdAt'>[] = [
      {
        slot: "helmet",
        itemName: "Decayed Helm",
        itemType: "Helmet",
        rarity: "rare",
        affixes: [
          { name: "Added Health", tier: 4, value: 65, maxValue: 90, isPreffix: true, priority: "high" },
          { name: "Fire Resistance", tier: 6, value: 18, maxValue: 20, isPreffix: false, priority: "medium" }
        ],
        totalAffixTiers: 10,
        weaknessScore: 45, // Moderate weakness due to T4 health
        gapAnalysis: {
          optimalAffixes: ["Added Health", "Armor", "Fire Resistance", "Critical Strike Avoidance"],
          missingAffixes: ["Armor", "Critical Strike Avoidance"],
          lowTierAffixes: [{ name: "Added Health", currentTier: 4, targetTier: 6 }],
          improvementPotential: 55,
          upgradeRecommendations: ["Find helmet with T6+ Added Health", "Add Armor or Critical Strike Avoidance"],
          estimatedUpgradeValue: 350
        }
      },
      {
        slot: "body_armor",
        itemName: "Wrapped Doublet",
        itemType: "Body Armor",
        rarity: "rare", 
        affixes: [
          { name: "Added Health", tier: 7, value: 88, maxValue: 90, isPreffix: true, priority: "high" },
          { name: "Armor", tier: 6, value: 195, maxValue: 220, isPreffix: true, priority: "high" },
          { name: "Fire Resistance", tier: 5, value: 16, maxValue: 20, isPreffix: false, priority: "medium" },
          { name: "Movement Speed", tier: 4, value: 6, maxValue: 9, isPreffix: false, priority: "medium" }
        ],
        totalAffixTiers: 22,
        weaknessScore: 15, // Good piece, only minor improvements needed
        gapAnalysis: {
          optimalAffixes: ["Added Health", "Armor", "Fire Resistance", "Movement Speed"],
          missingAffixes: [],
          lowTierAffixes: [{ name: "Movement Speed", currentTier: 4, targetTier: 6 }],
          improvementPotential: 25,
          upgradeRecommendations: ["Look for T6+ Movement Speed replacement", "Consider Legendary Potential version"],
          estimatedUpgradeValue: 120
        }
      },
      {
        slot: "weapon",
        itemName: "Voidsteel Sword", 
        itemType: "One Handed Sword",
        rarity: "rare",
        affixes: [
          { name: "Void Damage", tier: 5, value: 45, maxValue: 60, isPreffix: true, priority: "high" },
          { name: "Critical Strike Multiplier", tier: 3, value: 28, maxValue: 45, isPreffix: false, priority: "high" },
          { name: "Attack Speed", tier: 4, value: 8, maxValue: 12, isPreffix: false, priority: "medium" }
        ],
        totalAffixTiers: 12,
        weaknessScore: 75, // High weakness - low tier crit multi and missing key affixes
        gapAnalysis: {
          optimalAffixes: ["Void Damage", "Melee Void Damage", "Critical Strike Multiplier", "Attack Speed"],
          missingAffixes: ["Melee Void Damage"],
          lowTierAffixes: [
            { name: "Critical Strike Multiplier", currentTier: 3, targetTier: 7 },
            { name: "Attack Speed", currentTier: 4, targetTier: 6 }
          ],
          improvementPotential: 85,
          upgradeRecommendations: ["PRIORITY: Find weapon with T6+ Critical Strike Multiplier", "Add Melee Void Damage affix"],
          estimatedUpgradeValue: 950
        }
      }
    ];

    const mockIdols: Omit<CharacterIdol, 'id' | 'characterId' | 'createdAt'>[] = [
      {
        idolType: "large",
        position: 1,
        affixes: [
          { name: "Minion Damage", tier: 5, value: 15, maxValue: 18, isPreffix: true, priority: "high" },
          { name: "Added Health", tier: 4, value: 22, maxValue: 28, isPreffix: false, priority: "high" }
        ],
        totalAffixTiers: 9,
        weaknessScore: 40,
        gapAnalysis: {
          optimalAffixes: ["Void Damage", "Added Health", "Melee Attack Speed"],
          currentEfficiency: 70,
          improvementSuggestions: ["Replace with Void Knight specific idol", "Look for higher tier affixes"],
          enchantmentPotential: true
        }
      }
    ];

    return {
      character: mockCharacter,
      gear: mockGear,
      idols: mockIdols,
      confidence: 85
    };
  }

  async analyzeCharacterGaps(
    character: Character, 
    gear: CharacterGear[], 
    idols: CharacterIdol[],
    targetBuild: Build
  ): Promise<GapAnalysisResult> {
    
    // Calculate weakness scores and identify priority upgrades
    const gearWeaknesses = gear
      .map(piece => ({ slot: piece.slot, weakness: piece.weaknessScore, analysis: piece.gapAnalysis }))
      .sort((a, b) => b.weakness - a.weakness);

    const idolWeaknesses = idols
      .map(idol => ({ type: idol.idolType, position: idol.position, weakness: idol.weaknessScore }))
      .sort((a, b) => b.weakness - a.weakness);

    // Generate AI-enhanced gap analysis if available
    let aiAnalysis = null;
    try {
      if (process.env.OPENAI_API_KEY) {
        aiAnalysis = await this.generateAIGapAnalysis(character, gear, idols, targetBuild);
      }
    } catch (error) {
      console.warn("AI gap analysis failed:", error);
    }

    const weakestSlots = gearWeaknesses.slice(0, 3).map(g => g.slot);
    
    const prioritizedUpgrades: GapPriority[] = gearWeaknesses.map((weakness, index) => ({
      slot: weakness.slot,
      priority: 100 - (index * 15), // Higher priority for weaker items
      reason: `Weakness score: ${weakness.weakness}/100 - ${weakness.analysis?.upgradeRecommendations?.[0] || 'Needs optimization'}`,
      targetAffixes: weakness.analysis?.optimalAffixes || [],
      minTierThreshold: Math.max(5, 7 - Math.floor(index / 2)) // Stricter tiers for higher priority items
    }));

    const overallScore = Math.round(
      gear.reduce((sum, piece) => sum + (100 - piece.weaknessScore), 0) / gear.length
    );

    const improvementPotential = Math.round(
      gear.reduce((sum, piece) => sum + (piece.gapAnalysis?.improvementPotential || 0), 0) / gear.length
    );

    const recommendations = [
      `Focus on ${weakestSlots[0]} upgrade first - highest impact potential`,
      `Target T${prioritizedUpgrades[0]?.minTierThreshold}+ affixes for primary stats`,
      `Estimated DPS gain: ${gear.reduce((sum, piece) => sum + (piece.gapAnalysis?.estimatedUpgradeValue || 0), 0)}+`,
      ...(aiAnalysis?.recommendations || [])
    ];

    return {
      overallScore,
      weakestSlots,
      prioritizedUpgrades,
      improvementPotential,
      recommendations
    };
  }

  async generatePersonalizedFilter(
    character: Character,
    gapAnalysis: GapAnalysisResult,
    targetCorruption: number
  ): Promise<{ rules: any[], xmlContent: string, priorities: GapPriority[] }> {
    
    const build = character.currentBuildId 
      ? buildAnalyzer.getBuildById(character.currentBuildId)
      : null;

    if (!build) {
      throw new Error("Character must have an associated build for personalized filters");
    }

    // Create personalized rules that prioritize character's weakest slots
    const personalizedRules = [];
    let priority = 1;

    // Ultra-high priority for weakest slot upgrades
    const weakestSlot = gapAnalysis.weakestSlots[0];
    const weakestUpgrade = gapAnalysis.prioritizedUpgrades.find(u => u.slot === weakestSlot);
    
    if (weakestUpgrade) {
      personalizedRules.push({
        id: `upgrade-${weakestSlot}`,
        type: "highlight",
        conditions: {
          itemTypes: [weakestSlot.replace('_', ' ')],
          affixes: weakestUpgrade.targetAffixes.map(affix => ({
            name: affix,
            minTier: weakestUpgrade.minTierThreshold
          }))
        },
        color: "#FF1493", // Hot pink for priority upgrades
        priority: priority++
      });
    }

    // High priority for all weak slots
    gapAnalysis.prioritizedUpgrades.slice(0, 3).forEach(upgrade => {
      personalizedRules.push({
        id: `target-${upgrade.slot}`,
        type: "show",
        conditions: {
          itemTypes: [upgrade.slot.replace('_', ' ')],
          affixes: upgrade.targetAffixes.map(affix => ({
            name: affix,
            minTier: Math.max(4, upgrade.minTierThreshold - 1)
          }))
        },
        color: "#FFA500", // Orange for targeted upgrades
        priority: priority++
      });
    });

    // Standard build affixes at lower priority
    build.affixPriorities.forEach(affix => {
      personalizedRules.push({
        id: `build-${affix.toLowerCase().replace(/\s+/g, '-')}`,
        type: "show", 
        conditions: {
          itemTypes: build.itemTypes,
          affixes: [{ name: affix, minTier: 4 }]
        },
        color: "#87CEEB", // Light blue for build affixes
        priority: priority++
      });
    });

    // Hide all base rule
    personalizedRules.push({
      id: "hide-all-base",
      type: "hide",
      conditions: {},
      priority: 1000
    });

    const xmlContent = this.generatePersonalizedXML(personalizedRules, character, gapAnalysis);

    return {
      rules: personalizedRules,
      xmlContent,
      priorities: gapAnalysis.prioritizedUpgrades
    };
  }

  private async generateAIGapAnalysis(
    character: Character,
    gear: CharacterGear[],
    idols: CharacterIdol[], 
    targetBuild: Build
  ): Promise<{ recommendations: string[] }> {
    
    const prompt = `
Analyze this Last Epoch character's gear gaps and provide personalized upgrade recommendations.

CHARACTER: ${character.name} - Level ${character.level} ${character.className}/${character.mastery}
TARGET BUILD: ${targetBuild.name}

CURRENT GEAR ANALYSIS:
${gear.map(piece => `
- ${piece.slot}: ${piece.itemName} (Weakness: ${piece.weaknessScore}/100)
  Affixes: ${piece.affixes.map(a => `${a.name} T${a.tier}`).join(', ')}
  Missing: ${piece.gapAnalysis?.missingAffixes?.join(', ') || 'None'}
  Low Tiers: ${piece.gapAnalysis?.lowTierAffixes?.map(lt => `${lt.name} T${lt.currentTier}→T${lt.targetTier}`).join(', ') || 'None'}
`).join('')}

IDOL ANALYSIS:
${idols.map(idol => `
- ${idol.idolType} (Pos ${idol.position}): Weakness ${idol.weaknessScore}/100
  Affixes: ${idol.affixes.map(a => `${a.name} T${a.tier}`).join(', ')}
`).join('')}

TARGET BUILD PRIORITIES: ${targetBuild.affixPriorities.slice(0, 6).join(', ')}

Provide 3-5 specific, actionable upgrade recommendations focusing on the highest impact improvements first.
Consider corruption scaling, build synergies, and cost-effectiveness.

Return JSON: { "recommendations": ["string"] }
`;

    try {
      const response = await aiFilterService.generateOptimalFilter({
        build: targetBuild,
        playerLevel: character.level,
        targetCorruption: 300, // Default for analysis
        faction: "merchants_guild",
        strictnessLevel: "strict"
      });

      // Mock response for demonstration
      return {
        recommendations: [
          "Weapon upgrade is your highest priority - find T6+ Critical Strike Multiplier",
          "Consider Legendary crafting for your body armor to add movement speed",
          "Replace small idols with class-specific large idols for better efficiency",
          "Your resistances are capped - focus on offensive affixes for upgrades"
        ]
      };
    } catch (error) {
      return { recommendations: [] };
    }
  }

  private generatePersonalizedXML(
    rules: any[], 
    character: Character, 
    gapAnalysis: GapAnalysisResult
  ): string {
    const header = generateXMLHeader({
      characterName: `${character.name} (${character.className}/${character.mastery})`,
      playerLevel: character.level
    });

    const ruleXml = rules
      .sort((a, b) => a.priority - b.priority)
      .map(rule => ruleToXML(rule))
      .join('\n');

    return [header, `<!-- Overall Score: ${gapAnalysis.overallScore}/100 -->\n<!-- Weakest Slots: ${gapAnalysis.weakestSlots.join(', ')} -->`, ruleXml, generateXMLFooter()].join('\n');
  }

  // Removed ruleToXML - now using shared utility from xmlUtils

  async matchCharacterToBuild(character: Character): Promise<string | null> {
    const allBuilds = buildAnalyzer.getAllBuilds();
    
    // Simple matching by class and mastery
    const matchingBuilds = allBuilds.filter(build => 
      build.className === character.className && build.mastery === character.mastery
    );

    if (matchingBuilds.length === 0) return null;
    
    // Return the highest tier build that matches
    const bestMatch = matchingBuilds.sort((a, b) => a.tierRating - b.tierRating)[0];
    return bestMatch.id;
  }
}

export const characterAnalyzer = new CharacterAnalyzer();