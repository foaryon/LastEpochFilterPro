import type { Build, FilterRule, GeneratedFilter, InsertGeneratedFilter } from "@shared/schema";
import { ruleToXML, generateXMLHeader, generateXMLFooter, calculateStrictnessLevel } from "../utils/xmlUtils";

export interface StrictnessConfig {
  name: string;
  minAffixTier: number;
  totalTierThreshold: number;
  hideNormalMagic: boolean;
  requireMultipleAffixes: boolean;
  showLowLP: boolean;
}

const STRICTNESS_CONFIGS: Record<string, StrictnessConfig> = {
  regular: {
    name: "Regular",
    minAffixTier: 3,
    totalTierThreshold: 8,
    hideNormalMagic: false,
    requireMultipleAffixes: false,
    showLowLP: true
  },
  strict: {
    name: "Strict", 
    minAffixTier: 4,
    totalTierThreshold: 12,
    hideNormalMagic: true,
    requireMultipleAffixes: true,
    showLowLP: true
  },
  very_strict: {
    name: "Very Strict",
    minAffixTier: 5,
    totalTierThreshold: 16,
    hideNormalMagic: true,
    requireMultipleAffixes: true,
    showLowLP: false
  },
  uber_strict: {
    name: "Uber Strict",
    minAffixTier: 6,
    totalTierThreshold: 20,
    hideNormalMagic: true,
    requireMultipleAffixes: true,
    showLowLP: false
  },
  giga_strict: {
    name: "GIGA Strict",
    minAffixTier: 7,
    totalTierThreshold: 25,
    hideNormalMagic: true,
    requireMultipleAffixes: true,
    showLowLP: false
  }
};

export class FilterGenerator {
  generateProgressiveFilter(
    build: Build,
    playerLevel: number,
    targetCorruption: number,
    faction: "merchants_guild" | "circle_of_fortune" = "merchants_guild"
  ): { rules: FilterRule[], xmlContent: string, strictnessLevel: string } {
    
    // Determine appropriate strictness based on level and corruption
    const strictnessLevel = this.calculateStrictnessLevel(playerLevel, targetCorruption);
    const config = STRICTNESS_CONFIGS[strictnessLevel];
    
    const rules: FilterRule[] = [];
    let priority = 1;

    // 1. Hide all base rule (lowest priority)
    rules.push({
      id: "hide-all-base",
      type: "hide",
      conditions: {},
      priority: 1000
    });

    // 2. Always show currency and crafting materials
    rules.push({
      id: "show-currency",
      type: "show",
      conditions: {
        itemTypes: ["Glyph", "Rune", "Shard", "Gold"]
      },
      color: "#FFD700",
      priority: priority++
    });

    // 3. Show high LP uniques
    const minLP = config.showLowLP ? 1 : 2;
    rules.push({
      id: "show-high-lp-uniques",
      type: "highlight",
      conditions: {
        rarity: "unique",
        // Note: LP filtering would need game-specific syntax
      },
      color: "#FF6B35",
      priority: priority++
    });

    // 4. Show Legendary and Set items
    rules.push({
      id: "show-legendary-set",
      type: "highlight", 
      conditions: {
        rarity: "legendary"
      },
      color: "#FF1493",
      priority: priority++
    });

    rules.push({
      id: "show-set-items",
      type: "highlight",
      conditions: {
        rarity: "set"
      },
      color: "#32CD32", 
      priority: priority++
    });

    // 5. Build-specific gear with affix requirements
    const primaryAffixes = build.affixPriorities.slice(0, 4);
    const secondaryAffixes = build.affixPriorities.slice(4, 8);

    // Primary affixes (high tier required)
    rules.push({
      id: "primary-affixes-high-tier",
      type: "highlight",
      conditions: {
        itemTypes: build.itemTypes,
        affixes: primaryAffixes.map(affix => ({
          name: affix,
          minTier: Math.max(config.minAffixTier, 5)
        })),
        totalAffixTiers: config.totalTierThreshold
      },
      color: "#FF69B4", // Bright pink for best items
      priority: priority++
    });

    // Secondary affixes (medium tier)  
    rules.push({
      id: "secondary-affixes-medium-tier",
      type: "show",
      conditions: {
        itemTypes: build.itemTypes,
        affixes: secondaryAffixes.map(affix => ({
          name: affix,
          minTier: config.minAffixTier
        })),
        totalAffixTiers: Math.floor(config.totalTierThreshold * 0.7)
      },
      color: "#FFA500", // Orange for good items
      priority: priority++
    });

    // 6. Defensive requirements (scales with corruption)
    const defenseMultiplier = 1 + (targetCorruption * 0.002);
    const defensiveAffixes = [
      "Added Health",
      "Health", 
      "Fire Resistance",
      "Cold Resistance", 
      "Lightning Resistance",
      "Necrotic Resistance",
      "Void Resistance",
      "Armor",
      "Critical Strike Avoidance"
    ];

    rules.push({
      id: "defensive-requirements",
      type: "show",
      conditions: {
        itemTypes: build.itemTypes,
        affixes: defensiveAffixes.map(affix => ({
          name: affix,
          minTier: Math.max(3, Math.floor(config.minAffixTier * 0.8))
        }))
      },
      color: "#4169E1", // Blue for defensive
      priority: priority++
    });

    // 7. Idol rules
    rules.push({
      id: "class-idols-high-tier", 
      type: "show",
      conditions: {
        itemTypes: ["Large Idol", "Grand Idol", "Huge Idol", "Ornate Idol", "Adorned Idol"],
        affixes: primaryAffixes.concat(defensiveAffixes.slice(0, 3)).map(affix => ({
          name: affix,
          minTier: config.minAffixTier
        }))
      },
      color: "#9370DB", // Purple for idols
      priority: priority++
    });

    // 8. Faction-specific optimizations
    if (faction === "merchants_guild") {
      // Show items with good trade value
      rules.push({
        id: "trade-value-items",
        type: "show",
        conditions: {
          affixes: [
            { name: "Critical Strike Multiplier", minTier: 6 },
            { name: "Added Health", minTier: 6 },
            { name: "Movement Speed", minTier: 5 }
          ]
        },
        color: "#FFD700", // Gold for trade value
        priority: priority++
      });
    }

    // 9. Level-based progression rules
    if (playerLevel < 95) {
      // Show more lenient gear while leveling
      rules.push({
        id: "leveling-gear",
        type: "show", 
        conditions: {
          itemTypes: build.itemTypes,
          affixes: primaryAffixes.map(affix => ({
            name: affix,
            minTier: Math.max(2, config.minAffixTier - 2)
          }))
        },
        color: "#FFFFFF",
        priority: priority++
      });
    }

    const xmlContent = this.generateXML(rules, build, strictnessLevel);

    return {
      rules,
      xmlContent,
      strictnessLevel
    };
  }

  private calculateStrictnessLevel(playerLevel: number, targetCorruption: number): string {
    return calculateStrictnessLevel(targetCorruption);
  }

  private generateXML(rules: FilterRule[], build: Build, strictnessLevel: string): string {
    const header = generateXMLHeader({
      buildName: `${build.name} (${build.className}/${build.mastery})`,
      strictnessLevel
    });

    const ruleXml = rules
      .sort((a, b) => a.priority - b.priority)
      .map(rule => ruleToXML(rule))
      .join('\n');

    return [header, ruleXml, generateXMLFooter()].join('\n');
  }

  // Removed ruleToXML - now using shared utility from xmlUtils

  calculateDamageRequirement(build: Build, targetCorruption: number): number {
    // Base DPS calculations based on build type and corruption scaling
    let baseDPS = 800000; // 800k base DPS for S-tier builds

    // Build-specific multipliers
    const buildMultipliers: Record<string, number> = {
      "Warpath Void Knight": 1.2,
      "Ballista Falconer ZHP": 1.5, 
      "Abomination Necromancer": 1.0,
      "Bear Beastmaster": 0.9,
      "Erasing Strike Void Knight": 2.0, // Burst damage
      "Judgement Paladin": 1.1,
      "Lightning Blast Runemaster": 1.3,
      "Flay Mana Lich": 1.0,
      "Storm Crows Beastmaster": 1.1,
      "Anurok Frogs Beastmaster": 0.95,
      "Reflect Shaman": 0.8,
      "Tornado Werebear Druid": 1.0
    };

    const buildMultiplier = buildMultipliers[build.name] || 1.0;
    
    // Corruption scaling: ~3% monster health increase per level
    const corruptionMultiplier = Math.pow(1.03, targetCorruption);
    
    // Calculate final DPS requirement
    const requiredDPS = baseDPS * buildMultiplier * corruptionMultiplier;
    
    return Math.round(requiredDPS);
  }
}

export const filterGenerator = new FilterGenerator();
