import type { Build, InsertBuild, AIRecommendation } from "@shared/schema";

// Season 3 S-Tier builds database based on web research
const SEASON_3_BUILDS: InsertBuild[] = [
  {
    name: "Warpath Void Knight",
    className: "Sentinel", 
    mastery: "Void Knight",
    description: "Spin-to-win AoE dominance with endless mobility",
    playstyle: "Classic spin-to-win with endless mobility and screen-wide AoE",
    difficulty: "Intermediate",
    tierRating: 1, // S+
    bossRating: "S+",
    clearRating: "S+", 
    newbieRating: "A",
    isNew: false,
    affixPriorities: [
      "Void Damage",
      "Melee Void Damage", 
      "Added Health",
      "Melee Attack Speed",
      "Critical Strike Multiplier",
      "Elemental Resistances",
      "Movement Speed",
      "Armor"
    ],
    itemTypes: [
      "Two Handed Axe",
      "Two Handed Sword",
      "Two Handed Mace",
      "Body Armor",
      "Helmet", 
      "Gloves",
      "Boots",
      "Belt",
      "Ring",
      "Amulet",
      "Relic"
    ],
    defenseRequirements: {
      health: 3000,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 2000
    }
  },
  {
    name: "Ballista Falconer ZHP",
    className: "Rogue",
    mastery: "Falconer", 
    description: "Glass cannon turret master with explosive DPS",
    playstyle: "Zero Health Pool - Glass cannon turret summoner with explosive DPS",
    difficulty: "Advanced",
    tierRating: 1, // S+
    bossRating: "S+",
    clearRating: "S",
    newbieRating: "C", 
    isNew: true,
    affixPriorities: [
      "Bow Damage",
      "Physical Damage", 
      "Ballista Damage",
      "Attack Speed",
      "Critical Strike Chance",
      "Critical Strike Multiplier",
      "Dexterity",
      "Dodge Rating"
    ],
    itemTypes: [
      "Bow",
      "Quiver", 
      "Body Armor",
      "Helmet",
      "Gloves", 
      "Boots",
      "Belt",
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 1, // ZHP build
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 500
    }
  },
  {
    name: "Abomination Necromancer",
    className: "Acolyte",
    mastery: "Necromancer",
    description: "Ultimate minion powerhouse with tanky companion",
    playstyle: "Single powerful minion that scales to raid boss levels",
    difficulty: "Beginner",
    tierRating: 2, // S
    bossRating: "S",
    clearRating: "S",
    newbieRating: "A+",
    isNew: false,
    affixPriorities: [
      "Minion Damage",
      "Minion Health", 
      "Minion Attack Speed",
      "Necrotic Damage",
      "Added Health",
      "Minion Critical Strike Chance",
      "Intelligence",
      "Elemental Resistances"
    ],
    itemTypes: [
      "Staff",
      "Wand",
      "Focus",
      "Body Armor",
      "Helmet",
      "Gloves",
      "Boots", 
      "Belt",
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 2500,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 1500
    }
  },
  {
    name: "Bear Beastmaster", 
    className: "Primalist",
    mastery: "Beastmaster",
    description: "Tankiest S-tier option with massive primal companion",
    playstyle: "Fight alongside a massive primal companion",
    difficulty: "Beginner",
    tierRating: 2, // S
    bossRating: "S",
    clearRating: "A+",
    newbieRating: "S",
    isNew: false,
    affixPriorities: [
      "Minion Damage",
      "Minion Health",
      "Physical Damage",
      "Minion Attack Speed", 
      "Added Health",
      "Strength",
      "Armor",
      "Elemental Resistances"
    ],
    itemTypes: [
      "Two Handed Axe",
      "Two Handed Mace", 
      "Claw",
      "Body Armor",
      "Helmet",
      "Gloves",
      "Boots",
      "Belt", 
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 3500,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 2500
    }
  },
  {
    name: "Erasing Strike Void Knight",
    className: "Sentinel",
    mastery: "Void Knight",
    description: "Ultimate boss killer with unmatched single-target burst",
    playstyle: "One-shot burst damage specialist",
    difficulty: "Intermediate",
    tierRating: 2, // S
    bossRating: "S++",
    clearRating: "B+", 
    newbieRating: "B",
    isNew: false,
    affixPriorities: [
      "Void Damage",
      "Melee Void Damage",
      "Critical Strike Multiplier",
      "Critical Strike Chance",
      "Added Health",
      "Melee Attack Speed",
      "Strength",
      "Elemental Resistances"
    ],
    itemTypes: [
      "One Handed Sword",
      "One Handed Axe",
      "Shield", 
      "Body Armor",
      "Helmet",
      "Gloves",
      "Boots",
      "Belt",
      "Ring",
      "Amulet", 
      "Relic"
    ],
    defenseRequirements: {
      health: 2800,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 2200
    }
  },
  {
    name: "Judgement Paladin",
    className: "Sentinel", 
    mastery: "Paladin",
    description: "Holy fire AoE hybrid with persistent damage",
    playstyle: "Hybrid support-DPS with persistent AoE holy fire",
    difficulty: "Beginner",
    tierRating: 2, // S
    bossRating: "A+",
    clearRating: "S",
    newbieRating: "A+",
    isNew: true,
    affixPriorities: [
      "Fire Damage",
      "Spell Fire Damage",
      "Added Health", 
      "Spell Critical Strike Chance",
      "Spell Critical Strike Multiplier",
      "Attunement",
      "Mana",
      "Elemental Resistances"
    ],
    itemTypes: [
      "Sceptre",
      "Shield",
      "Staff",
      "Body Armor",
      "Helmet", 
      "Gloves",
      "Boots",
      "Belt",
      "Ring",
      "Amulet",
      "Relic"
    ],
    defenseRequirements: {
      health: 2700,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 1800
    }
  },
  {
    name: "Lightning Blast Runemaster",
    className: "Mage",
    mastery: "Runemaster", 
    description: "Elemental burst damage specialist",
    playstyle: "Elemental burst damage specialist",
    difficulty: "Intermediate",
    tierRating: 3, // A+
    bossRating: "A+",
    clearRating: "S",
    newbieRating: "B+",
    isNew: false,
    affixPriorities: [
      "Lightning Damage",
      "Spell Lightning Damage",
      "Spell Critical Strike Chance",
      "Spell Critical Strike Multiplier", 
      "Cast Speed",
      "Added Health",
      "Intelligence",
      "Mana"
    ],
    itemTypes: [
      "Staff",
      "Wand",
      "Focus",
      "Body Armor", 
      "Helmet",
      "Gloves",
      "Boots",
      "Belt",
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 2200,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 1200
    }
  },
  {
    name: "Flay Mana Lich",
    className: "Acolyte",
    mastery: "Lich",
    description: "Sustain-based caster with mana-to-health conversion", 
    playstyle: "Sustain-based caster",
    difficulty: "Intermediate",
    tierRating: 3, // A+
    bossRating: "A+",
    clearRating: "A+",
    newbieRating: "B",
    isNew: false,
    affixPriorities: [
      "Necrotic Damage",
      "Spell Necrotic Damage",
      "Cast Speed",
      "Mana",
      "Spell Critical Strike Chance",
      "Intelligence", 
      "Ward Retention",
      "Elemental Resistances"
    ],
    itemTypes: [
      "Staff",
      "Wand",
      "Focus",
      "Body Armor",
      "Helmet",
      "Gloves", 
      "Boots",
      "Belt",
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 1800,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 1000
    }
  },
  {
    name: "Storm Crows Beastmaster",
    className: "Primalist",
    mastery: "Beastmaster",
    description: "Flying minion army with elemental damage",
    playstyle: "Flying minion army", 
    difficulty: "Intermediate",
    tierRating: 3, // A
    bossRating: "A",
    clearRating: "S",
    newbieRating: "A",
    isNew: false,
    affixPriorities: [
      "Minion Damage",
      "Lightning Damage",
      "Minion Attack Speed",
      "Minion Health", 
      "Added Health",
      "Attunement",
      "Elemental Resistances",
      "Cast Speed"
    ],
    itemTypes: [
      "Staff",
      "Sceptre",
      "Focus",
      "Body Armor",
      "Helmet",
      "Gloves",
      "Boots", 
      "Belt",
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 2300,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 1400
    }
  },
  {
    name: "Anurok Frogs Beastmaster",
    className: "Primalist",
    mastery: "Beastmaster",
    description: "Poison swarm specialist with amphibian minions",
    playstyle: "Poison swarm specialist",
    difficulty: "Intermediate", 
    tierRating: 3, // A
    bossRating: "A",
    clearRating: "A+",
    newbieRating: "A",
    isNew: false,
    affixPriorities: [
      "Minion Damage",
      "Poison Damage",
      "Damage Over Time",
      "Minion Health",
      "Added Health",
      "Minion Attack Speed", 
      "Attunement",
      "Elemental Resistances"
    ],
    itemTypes: [
      "Staff",
      "Sceptre", 
      "Focus",
      "Body Armor",
      "Helmet",
      "Gloves",
      "Boots",
      "Belt",
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 2400,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 1300
    }
  },
  {
    name: "Reflect Shaman",
    className: "Primalist",
    mastery: "Shaman", 
    description: "Counter-attack specialist with thorns damage",
    playstyle: "Counter-attack specialist",
    difficulty: "Intermediate",
    tierRating: 3, // A
    bossRating: "A",
    clearRating: "A",
    newbieRating: "B+",
    isNew: false,
    affixPriorities: [
      "Attunement",
      "Lightning Damage",
      "Spell Lightning Damage", 
      "Added Health",
      "Spell Critical Strike Chance",
      "Cast Speed",
      "Elemental Resistances",
      "Mana"
    ],
    itemTypes: [
      "Staff",
      "Sceptre",
      "Focus", 
      "Body Armor",
      "Helmet",
      "Gloves",
      "Boots",
      "Belt",
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 2600,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 1600
    }
  },
  {
    name: "Tornado Werebear Druid",
    className: "Primalist",
    mastery: "Druid",
    description: "Shapeshifter AoE master with wind magic",
    playstyle: "Shapeshifter AoE master", 
    difficulty: "Intermediate",
    tierRating: 3, // A
    bossRating: "A",
    clearRating: "A+",
    newbieRating: "A",
    isNew: false,
    affixPriorities: [
      "Physical Damage",
      "Melee Physical Damage",
      "Added Health",
      "Melee Attack Speed",
      "Strength", 
      "Critical Strike Chance",
      "Armor",
      "Elemental Resistances"
    ],
    itemTypes: [
      "Two Handed Axe",
      "Two Handed Mace",
      "Claw",
      "Body Armor", 
      "Helmet",
      "Gloves",
      "Boots",
      "Belt",
      "Ring",
      "Amulet"
    ],
    defenseRequirements: {
      health: 3200,
      resistances: { "Fire": 75, "Cold": 75, "Lightning": 75, "Necrotic": 75, "Void": 75 },
      armor: 2300
    }
  }
];

export class BuildAnalyzer {
  private builds: Map<string, Build> = new Map();

  constructor() {
    // Initialize with Season 3 build data
    this.loadBuilds();
  }

  private loadBuilds(): void {
    SEASON_3_BUILDS.forEach((buildData, index) => {
      const build: Build = {
        ...buildData,
        id: this.generateBuildId(buildData.name),
        isNew: buildData.isNew ?? false,
        createdAt: new Date()
      };
      this.builds.set(build.id, build);
    });
  }

  private generateBuildId(name: string): string {
    return name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  }

  getAllBuilds(): Build[] {
    return Array.from(this.builds.values());
  }

  getBuildById(id: string): Build | undefined {
    return this.builds.get(id);
  }

  getBuildsByClass(className: string): Build[] {
    return Array.from(this.builds.values()).filter(build => build.className === className);
  }

  getBuildsByMastery(mastery: string): Build[] {
    return Array.from(this.builds.values()).filter(build => build.mastery === mastery);
  }

  getNewBuilds(): Build[] {
    return Array.from(this.builds.values()).filter(build => build.isNew);
  }

  getTierBuilds(tier: number): Build[] {
    return Array.from(this.builds.values()).filter(build => build.tierRating === tier);
  }

  analyzeAffixPriority(build: Build, targetCorruption: number): AIRecommendation[] {
    const recommendations: AIRecommendation[] = [];
    
    // Base affix analysis
    const primaryAffixes = build.affixPriorities.slice(0, 3);
    const secondaryAffixes = build.affixPriorities.slice(3, 6); 
    const defensiveAffixes = build.affixPriorities.filter(affix => 
      affix.includes('Health') || affix.includes('Resistance') || affix.includes('Armor')
    );

    recommendations.push({
      type: "affix_priority",
      description: `Primary focus: ${primaryAffixes.join(', ')}. These should be T6+ for corruption 300+`,
      impact: "high",
      confidence: 95,
      data: { primaryAffixes, minTier: targetCorruption >= 300 ? 6 : 4 }
    });

    if (targetCorruption >= 500) {
      recommendations.push({
        type: "tier_threshold", 
        description: `At ${targetCorruption} corruption, only accept T7 primary affixes and T6+ secondary affixes`,
        impact: "high",
        confidence: 90,
        data: { primaryMinTier: 7, secondaryMinTier: 6 }
      });
    }

    // Defensive scaling for corruption
    if (targetCorruption >= 200 && defensiveAffixes.length > 0) {
      recommendations.push({
        type: "corruption_scaling",
        description: `Defensive requirements scale significantly. Prioritize: ${defensiveAffixes.join(', ')}`,
        impact: "high", 
        confidence: 85,
        data: { 
          requiredHealth: build.defenseRequirements.health * (1 + targetCorruption * 0.002),
          requiredResistances: 75,
          defensiveAffixes 
        }
      });
    }

    return recommendations;
  }

  calculateOptimalProgression(build: Build, currentLevel: number): {
    levelingThresholds: number[];
    gearProgression: Record<number, string[]>;
    corruptionMilestones: number[];
  } {
    return {
      levelingThresholds: [90, 95, 100], // Empowered unlock, gear refinement, endgame focus
      gearProgression: {
        90: ["Focus on basic resistances", "T4+ primary affixes", "Movement speed priority"],
        95: ["T5+ primary affixes", "Begin legendary crafting", "Corruption scaling preparation"], 
        100: ["T6+ requirements", "Perfect base types", "LP 2+ targeting"]
      },
      corruptionMilestones: [100, 300, 500, 800] // Major power breakpoints
    };
  }
}

export const buildAnalyzer = new BuildAnalyzer();
