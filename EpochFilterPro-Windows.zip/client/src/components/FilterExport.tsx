import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface FilterExportProps {
  generatedFilter?: any;
  isLoading: boolean;
}

export default function FilterExport({ generatedFilter, isLoading }: FilterExportProps) {
  const { toast } = useToast();

  const handleDownload = async () => {
    if (!generatedFilter?.filterId) {
      toast({
        title: "No Filter Available",
        description: "Please generate a filter first by selecting a build.",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch(`/api/filters/${generatedFilter.filterId}/export`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to download filter");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `${generatedFilter.buildName?.replace(/\s+/g, '_') || 'filter'}.xml`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Filter Downloaded",
        description: "Loot filter has been saved to your downloads folder.",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Could not download the filter. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePreview = () => {
    if (!generatedFilter?.xmlContent) {
      toast({
        title: "No Filter Available",
        description: "Please generate a filter first by selecting a build.",
        variant: "destructive",
      });
      return;
    }

    // Open preview in new window/modal
    const previewWindow = window.open('', '_blank');
    if (previewWindow) {
      previewWindow.document.write(`
        <html>
          <head><title>Filter Preview - ${generatedFilter.buildName}</title></head>
          <body style="font-family: monospace; padding: 20px; background: #1a1a1a; color: #e0e0e0;">
            <h2>Last Epoch Loot Filter Preview</h2>
            <h3>${generatedFilter.buildName} - ${generatedFilter.strictnessLevel}</h3>
            <pre style="white-space: pre-wrap; background: #2a2a2a; padding: 15px; border-radius: 8px; overflow-x: auto;">
${generatedFilter.xmlContent}
            </pre>
          </body>
        </html>
      `);
      previewWindow.document.close();
    }
  };

  const handleCopyToClipboard = () => {
    if (!generatedFilter?.xmlContent) {
      toast({
        title: "No Filter Available",
        description: "Please generate a filter first by selecting a build.",
        variant: "destructive",
      });
      return;
    }

    navigator.clipboard.writeText(generatedFilter.xmlContent).then(() => {
      toast({
        title: "Filter Copied",
        description: "Filter XML has been copied to your clipboard.",
      });
    }).catch(() => {
      toast({
        title: "Copy Failed",
        description: "Could not copy filter to clipboard. Please try again.",
        variant: "destructive",
      });
    });
  };

  return (
    <div className="bg-card border border-border rounded-xl p-6" data-testid="panel-filter-export">
      <h3 className="text-lg font-bold mb-4">Export Filter</h3>
      <div className="space-y-3">
        <Button 
          onClick={handleDownload}
          disabled={isLoading || !generatedFilter}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3 px-4 transition-colors flex items-center justify-center"
          data-testid="button-download-filter"
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2"></div>
              Generating...
            </>
          ) : (
            <>
              <i className="fas fa-download mr-2"></i>
              Generate & Export (.xml)
            </>
          )}
        </Button>
        
        <Button 
          variant="outline"
          onClick={handlePreview}
          disabled={isLoading || !generatedFilter}
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-medium py-3 px-4 transition-colors flex items-center justify-center"
          data-testid="button-preview-filter"
        >
          <i className="fas fa-eye mr-2"></i>
          Preview Filter Rules
        </Button>
        
        <Button 
          variant="secondary"
          onClick={handleCopyToClipboard}
          disabled={isLoading || !generatedFilter}
          className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground font-medium py-3 px-4 transition-colors flex items-center justify-center"
          data-testid="button-copy-filter"
        >
          <i className="fas fa-copy mr-2"></i>
          Copy to Clipboard
        </Button>
      </div>
      
      {generatedFilter && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="text-sm text-muted-foreground space-y-1">
            <p><span className="font-medium">Build:</span> {generatedFilter.buildName}</p>
            <p><span className="font-medium">Strictness:</span> {generatedFilter.strictnessLevel}</p>
            <p><span className="font-medium">Rules:</span> {generatedFilter.rules?.length || 0} total</p>
            <p><span className="font-medium">Generated:</span> {new Date(generatedFilter.metadata?.generatedAt || Date.now()).toLocaleTimeString()}</p>
          </div>
        </div>
      )}
    </div>
  );
}
