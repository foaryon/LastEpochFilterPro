import { memo } from "react";
import { cn } from "@/lib/utils";
import type { Build } from "@shared/schema";

interface BuildCardProps {
  build: Build;
  isSelected: boolean;
  onSelect: () => void;
}

const BuildCard = memo(function BuildCard({ build, isSelected, onSelect }: BuildCardProps) {
  const getRankBadge = (tierRating: number) => {
    if (tierRating === 1) return { text: "#1", className: "rarity-unique font-bold" };
    if (tierRating <= 3) return { text: `#${tierRating}`, className: "rarity-exalted font-bold" };
    return { text: `#${tierRating}`, className: "rarity-rare" };
  };

  const getBuildIcon = (buildName: string, className: string) => {
    // Map specific builds to appropriate Font Awesome icons
    const buildIconMap: Record<string, { icon: string; color: string }> = {
      // Sentinel builds
      "Warpath Void Knight": { icon: "fa-tornado", color: "void-text" },
      "Erasing Strike Void Knight": { icon: "fa-burst", color: "void-text" },
      "Judgement Paladin": { icon: "fa-gavel", color: "gold-text" },
      
      // Rogue builds
      "Ballista Falconer ZHP": { icon: "fa-crosshairs", color: "damage-physical" },
      
      // Acolyte builds
      "Abomination Necromancer": { icon: "fa-skull", color: "damage-necrotic" },
      "Flay Mana Lich": { icon: "fa-ghost", color: "damage-necrotic" },
      
      // Primalist builds
      "Bear Beastmaster": { icon: "fa-paw", color: "damage-physical" },
      "Storm Crows Beastmaster": { icon: "fa-crow", color: "damage-lightning" },
      "Anurok Frogs Beastmaster": { icon: "fa-frog", color: "damage-poison" },
      "Reflect Shaman": { icon: "fa-shield-halved", color: "damage-lightning" },
      "Tornado Werebear Druid": { icon: "fa-wind", color: "damage-physical" },
      
      // Mage builds
      "Lightning Blast Runemaster": { icon: "fa-bolt", color: "damage-lightning" },
    };
    
    // Fallback icons based on class
    const classIconMap: Record<string, { icon: string; color: string }> = {
      "Sentinel": { icon: "fa-shield-alt", color: "damage-physical" },
      "Rogue": { icon: "fa-user-ninja", color: "damage-physical" },
      "Acolyte": { icon: "fa-book-skull", color: "damage-necrotic" },
      "Primalist": { icon: "fa-leaf", color: "damage-physical" },
      "Mage": { icon: "fa-hat-wizard", color: "damage-fire" },
    };
    
    return buildIconMap[buildName] || classIconMap[className] || { icon: "fa-dice-d20", color: "text-muted-foreground" };
  };

  const rankBadge = getRankBadge(build.tierRating);
  const buildIcon = getBuildIcon(build.name, build.className);

  return (
    <div
      className={cn(
        "build-card gothic-border rounded-lg p-4 cursor-pointer transition-all duration-300",
        isSelected ? "item-frame-unique neon-glow" : "item-frame-normal"
      )}
      onClick={onSelect}
      data-testid={`card-build-${build.id}`}
    >
      <div className="flex items-center justify-between mb-3">
        <div 
          className={cn(
            "w-10 h-10 rounded-lg flex items-center justify-center",
            "bg-gradient-to-br from-accent to-background border border-border",
            buildIcon.color
          )}
          data-testid={`img-build-${build.id}`}
        >
          <i className={cn("fas", buildIcon.icon, "text-xl")}></i>
        </div>
        <div className={cn("px-2 py-1 rounded text-xs", rankBadge.className, build.isNew && "mystical-glow")} data-testid={`badge-rank-${build.id}`}>
          {build.isNew ? "NEW" : rankBadge.text}
        </div>
      </div>
      
      <h3 className="font-semibold mb-1 gold-text" data-testid={`text-build-name-${build.id}`}>
        {build.name}
      </h3>
      
      <p className="text-sm text-muted-foreground mb-2" data-testid={`text-build-desc-${build.id}`}>
        {build.description}
      </p>
      
      <div className="flex items-center justify-between text-xs">
        <span 
          className={cn(
            build.bossRating.includes("S") ? "rarity-exalted" : 
            build.bossRating.includes("A") ? "rarity-rare" : "text-muted-foreground"
          )}
          data-testid={`rating-boss-${build.id}`}
        >
          Boss: {build.bossRating}
        </span>
        <span 
          className={cn(
            build.clearRating.includes("S") ? "rarity-exalted" : 
            build.clearRating.includes("A") ? "rarity-rare" : "text-muted-foreground"
          )}
          data-testid={`rating-clear-${build.id}`}
        >
          Clear: {build.clearRating}
        </span>
        <span 
          className={cn(
            build.newbieRating.includes("S") || build.newbieRating.includes("A") ? "text-chart-4" : 
            build.newbieRating.includes("B") ? "text-chart-3" : "text-destructive"
          )}
          data-testid={`rating-newbie-${build.id}`}
        >
          Newbie: {build.newbieRating}
        </span>
      </div>
      
      {build.isNew && (
        <div className="mt-2 bg-primary/20 text-primary px-2 py-1 rounded text-xs text-center font-medium">
          Season 3 Addition
        </div>
      )}
    </div>
  );
}, (prevProps, nextProps) => {
  return prevProps.build.id === nextProps.build.id && 
         prevProps.isSelected === nextProps.isSelected;
});

export default BuildCard;
